/*
 * ╔══════════════════════════════════════════════════════════════════╗
 * ║   Arduino Uno — Controlador de Motor (Escravo Serial)           ║
 * ║   Hardware : L298N grande (com dissipador)                      ║
 * ║              ENA e ENB com JUMPER para 5V (obrigatorio!)        ║
 * ║              Motor A → IN1=7, IN2=8                             ║
 * ║              Motor B → IN3=4, IN4=5                             ║
 * ║   Comunicacao: SoftwareSerial RX pino 10 @ 9600 bps            ║
 * ║                <- Mega TX1 (pino 18)                            ║
 * ╚══════════════════════════════════════════════════════════════════╝
 *
 * FIACAO L298N:
 *   ENA  -> jumper curto para o 5V ao lado (habilita Motor A)
 *   ENB  -> jumper curto para o 5V ao lado (habilita Motor B)
 *   IN1  -> pino 7 do Uno
 *   IN2  -> pino 8 do Uno
 *   IN3  -> pino 4 do Uno
 *   IN4  -> pino 5 do Uno
 *   OUT1/OUT2 -> terminais Motor A
 *   OUT3/OUT4 -> terminais Motor B
 *   GND  -> GND do Uno e GND da fonte do motor
 *   +12V -> fonte externa do motor (6-12V)
 *   5V   -> NAO conectar ao Uno se usar fonte externa acima de 7V
 *
 * FIACAO SERIAL:
 *   Mega pino 18 (TX1) -> Uno pino 10 (RX SoftwareSerial)
 *   GND Mega -> GND Uno (obrigatorio!)
 *
 * PROTOCOLO SERIAL:
 *   'A' -> gira Motor A por 9 segundos
 *   'B' -> gira Motor B por 9 segundos
 *   'W' -> ignorado
 */

#include <SoftwareSerial.h>

// --- Serial ------------------------------------------------------------------
#define RX_PIN 10   // recebe do Mega TX1 (pino 18)
#define TX_PIN 11   // nao usado, mas SoftwareSerial exige declarar
SoftwareSerial megaSerial(RX_PIN, TX_PIN);

// --- Pinos motor -------------------------------------------------------------
#define IN1   7   // Motor A direcao +
#define IN2   8   // Motor A direcao -
#define IN3   4   // Motor B direcao +
#define IN4   5   // Motor B direcao -

#define MOTOR_RUN_MS 9000UL  // tempo de giro: 9 segundos

static bool          motorRodando = false;
static char          motorAtivo   = 0;
static unsigned long motorInicio  = 0;

// --- Funcoes de controle -----------------------------------------------------
void ligarMotorA() {
  digitalWrite(IN1, LOW);
  digitalWrite(IN2, HIGH);
}

void ligarMotorB() {
  digitalWrite(IN3, LOW);
  digitalWrite(IN4, HIGH);
}

void pararMotores() {
  digitalWrite(IN1, LOW);
  digitalWrite(IN2, LOW);
  digitalWrite(IN3, LOW);
  digitalWrite(IN4, LOW);
}

// --- Setup -------------------------------------------------------------------
void setup() {
  megaSerial.begin(9600);

  pinMode(IN1, OUTPUT); pinMode(IN2, OUTPUT);
  pinMode(IN3, OUTPUT); pinMode(IN4, OUTPUT);
  pararMotores();

  // Pisca Motor A 400ms no boot para confirmar que hardware esta OK
  // Se o motor nao pulsou aqui -> verificar jumpers ENA/ENB e alimentacao
  ligarMotorA(); delay(400); pararMotores();
}

// --- Loop --------------------------------------------------------------------
void loop() {
  unsigned long agora = millis();

  if (megaSerial.available()) {
    char cmd = megaSerial.read();

    if (cmd == 'A') {
      pararMotores();
      motorAtivo = 'A'; motorInicio = agora; motorRodando = true;
      ligarMotorA();
    }
    else if (cmd == 'B') {
      pararMotores();
      motorAtivo = 'B'; motorInicio = agora; motorRodando = true;
      ligarMotorB();
    }
    // 'W' ignorado
  }

  // Para o motor apos MOTOR_RUN_MS milissegundos
  if (motorRodando && (agora - motorInicio >= MOTOR_RUN_MS)) {
    pararMotores();
    motorRodando = false;
    motorAtivo   = 0;
  }
}
