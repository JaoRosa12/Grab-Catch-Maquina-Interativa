#pragma once
/*
 * buttons.h — 4 botões físicos externos (push-buttons com pull-up interno)
 *
 * Pinos padrão (fáceis de mudar aqui):
 *   BTN1_PIN = 22  ← Menu: jogo 1 (Pong)   | Quiz: opção A | Pong: raquete CIMA
 *   BTN2_PIN = 23  ← Menu: jogo 2 (Velha)  | Quiz: opção B | Pong: raquete BAIXO
 *   BTN3_PIN = 24  ← Menu: jogo 3 (Quiz)   | Quiz: opção C
 *   BTN4_PIN = 25  ← Menu: jogo 4 (Memória)| Quiz: opção D
 *
 * Ligação: botão entre o pino e GND (INPUT_PULLUP ativo).
 *
 * API:
 *   buttonsInit()          → chame no setup()
 *   buttonsUpdate()        → chame UMA VEZ por loop(), antes de ler estados
 *   btnPressed(n)          → true se botão n (1..4) está pressionado agora
 *   btnJustPressed(n)      → borda de subida com debounce (1 disparo por toque)
 */

#include <Arduino.h>

#define BTN1_PIN 42
#define BTN2_PIN 43
#define BTN3_PIN 44
#define BTN4_PIN 45

#define BTN_COUNT        4
#define BTN_DEBOUNCE_MS  50   // ms de debounce para justPressed

void buttonsInit();
void buttonsUpdate();
bool btnPressed(uint8_t n);      // n = 1..4
bool btnJustPressed(uint8_t n);  // n = 1..4
