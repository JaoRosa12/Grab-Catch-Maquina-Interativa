/*
 * velha.cpp — Jogo da Velha vs CPU usando Minimax
 */

#include "velha.h"
#include "touch.h"

// ─────────────────────────────────────────────────────────────────────────────
// CONSTANTES
// ─────────────────────────────────────────────────────────────────────────────
#define VELHA_CELL       72
#define VELHA_SIZE       (VELHA_CELL*3)
#define VELHA_OX         ((SCREEN_W-VELHA_SIZE)/2)
#define VELHA_OY         ((SCREEN_H-VELHA_SIZE)/2)
#define VX_COLOR         NEON_PINK
#define VO_COLOR         NEON_CYAN
#define VG_COLOR         NEON_GREEN
#define VBG_COLOR        RGB(2,6,18)
#define VELHA_WIN_SCORE  3
#define VICTORY_DELAY_MS 3000

// ─────────────────────────────────────────────────────────────────────────────
// ESTADO INTERNO
// ─────────────────────────────────────────────────────────────────────────────
static int  velhaBoard[3][3];
static int  velhaPlayer;
static bool velhaOver = false;
static int  velhaWins[2] = {0, 0};
static bool velhaDone = false;

static bool          velhaVictoryPending   = false;
static int           velhaVictoryWinner    = 0;
static unsigned long velhaVictoryStartTime = 0;

// ─────────────────────────────────────────────────────────────────────────────
// MINIMAX
// ─────────────────────────────────────────────────────────────────────────────
static int mmBoard[3][3];

static int mmCheck() {
  for (int i = 0; i < 3; i++) {
    if (mmBoard[i][0] && mmBoard[i][0]==mmBoard[i][1] && mmBoard[i][1]==mmBoard[i][2]) return mmBoard[i][0];
    if (mmBoard[0][i] && mmBoard[0][i]==mmBoard[1][i] && mmBoard[1][i]==mmBoard[2][i]) return mmBoard[0][i];
  }
  if (mmBoard[0][0] && mmBoard[0][0]==mmBoard[1][1] && mmBoard[1][1]==mmBoard[2][2]) return mmBoard[0][0];
  if (mmBoard[0][2] && mmBoard[0][2]==mmBoard[1][1] && mmBoard[1][1]==mmBoard[2][0]) return mmBoard[0][2];
  return 0;
}

static bool mmFull() {
  for (int r = 0; r < 3; r++) for (int c = 0; c < 3; c++) if (!mmBoard[r][c]) return false;
  return true;
}

static int minimax(int depth, bool isMax) {
  int w = mmCheck();
  if (w==2) return 10-depth;
  if (w==1) return depth-10;
  if (mmFull()) return 0;
  int best = isMax ? -100 : 100;
  for (int r = 0; r < 3; r++) {
    for (int c = 0; c < 3; c++) {
      if (mmBoard[r][c]==0) {
        mmBoard[r][c] = isMax ? 2 : 1;
        int val = minimax(depth+1, !isMax);
        mmBoard[r][c] = 0;
        if (isMax) { if (val > best) best = val; }
        else       { if (val < best) best = val; }
      }
    }
  }
  return best;
}

static void cpuBestMove(int &bestR, int &bestC) {
  for (int r = 0; r < 3; r++) for (int c = 0; c < 3; c++) mmBoard[r][c] = velhaBoard[r][c];
  int bestVal = -100; bestR = -1; bestC = -1;
  for (int r = 0; r < 3; r++) {
    for (int c = 0; c < 3; c++) {
      if (mmBoard[r][c]==0) {
        mmBoard[r][c] = 2;
        int val = minimax(0, false);
        mmBoard[r][c] = 0;
        if (val > bestVal) { bestVal=val; bestR=r; bestC=c; }
      }
    }
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// DESENHO
// ─────────────────────────────────────────────────────────────────────────────
static void velhaDrawGrid() {
  tft.fillRect(VELHA_OX, VELHA_OY, VELHA_SIZE, VELHA_SIZE, VBG_COLOR);
  tft.drawRect(VELHA_OX-2, VELHA_OY-2, VELHA_SIZE+4, VELHA_SIZE+4, DARK_GREEN);
  tft.drawRect(VELHA_OX-1, VELHA_OY-1, VELHA_SIZE+2, VELHA_SIZE+2, VG_COLOR);
  for (int i = 1; i < 3; i++) {
    int lx = VELHA_OX+i*VELHA_CELL, ly = VELHA_OY+i*VELHA_CELL;
    tft.fillRect(lx-1, VELHA_OY, 3, VELHA_SIZE, DARK_GREEN);
    tft.drawFastVLine(lx, VELHA_OY, VELHA_SIZE, VG_COLOR);
    tft.fillRect(VELHA_OX, ly-1, VELHA_SIZE, 3, DARK_GREEN);
    tft.drawFastHLine(VELHA_OX, ly, VELHA_SIZE, VG_COLOR);
  }
}

static void velhaDrawSidebar() {
  tft.fillRect(0, 0, VELHA_OX, SCREEN_H, BLACK);
  tft.fillRect(VELHA_OX+VELHA_SIZE, 0, VELHA_OX, SCREEN_H, BLACK);
  drawStar4(VELHA_OX/2, SCREEN_H/4,   4, COL_GOLD);
  drawStar4(VELHA_OX/2, SCREEN_H*3/4, 4, COL_GOLD);
  int rx = VELHA_OX+VELHA_SIZE;
  drawStar4(rx+VELHA_OX/2, SCREEN_H/4,   4, COL_GOLD);
  drawStar4(rx+VELHA_OX/2, SCREEN_H*3/4, 4, COL_GOLD);

  if (!velhaOver) {
    int lx=2, lw=VELHA_OX-4;
    tft.setTextSize(1); tft.setTextColor(GRAY);
    tft.setCursor(lx, 32); tft.print(velhaPlayer==1 ? "SUA" : "CPU");
    tft.setCursor(lx, 42); tft.print("VEZ");
    int cx2=lx+lw/2, cy2=SCREEN_H/2, r=17;
    if (velhaPlayer==1) {
      tft.drawLine(cx2-r, cy2-r, cx2+r, cy2+r, VX_COLOR);
      tft.drawLine(cx2-r+1, cy2-r, cx2+r+1, cy2+r, VX_COLOR);
      tft.drawLine(cx2-r, cy2-r+1, cx2+r, cy2+r+1, VX_COLOR);
      tft.drawLine(cx2-r, cy2+r, cx2+r, cy2-r, VX_COLOR);
      tft.drawLine(cx2-r+1, cy2+r, cx2+r+1, cy2-r, VX_COLOR);
      tft.drawLine(cx2-r, cy2+r-1, cx2+r, cy2-r-1, VX_COLOR);
      tft.setTextColor(VX_COLOR); tft.setCursor(lx, 52); tft.print(" (X)");
    } else {
      tft.drawCircle(cx2, cy2, r,   VO_COLOR);
      tft.drawCircle(cx2, cy2, r-1, VO_COLOR);
      tft.drawCircle(cx2, cy2, r-2, DARK_CYAN);
      tft.setTextColor(VO_COLOR); tft.setCursor(lx, 52); tft.print(" (O)");
    }
  }

  int rx2 = VELHA_OX+VELHA_SIZE+2;
  tft.setTextSize(1); tft.setTextColor(VX_COLOR);
  tft.setCursor(rx2+2, 70);  tft.print("YOU");
  tft.setCursor(rx2+2, 80);  tft.print(" X");
  tft.setTextSize(2); tft.setCursor(rx2+4, 92); tft.print(velhaWins[0]);
  tft.setTextSize(1); tft.setTextColor(MIDGRAY);
  tft.setCursor(rx2+2, 112); tft.print("/"); tft.print(VELHA_WIN_SCORE);
  tft.setTextColor(VO_COLOR);
  tft.setCursor(rx2+2, 124); tft.print("CPU");
  tft.setCursor(rx2+2, 134); tft.print(" O");
  tft.setTextSize(2); tft.setCursor(rx2+4, 146); tft.print(velhaWins[1]);
  tft.setTextSize(1);
}

static void velhaDrawScene() {
  tft.fillScreen(BLACK);
  drawStarfield();
  velhaDrawGrid();
  velhaDrawSidebar();
  drawBackButton(NEON_CYAN);
}

static void velhaDrawPiece(int col, int row, int player) {
  int cx = VELHA_OX+col*VELHA_CELL+VELHA_CELL/2;
  int cy = VELHA_OY+row*VELHA_CELL+VELHA_CELL/2;
  int r  = VELHA_CELL/2-10;
  if (player==1) {
    for (int t = 0; t < 3; t++) {
      int o = t-1;
      tft.drawLine(cx-r+o, cy-r, cx+r+o, cy+r, (t==1)?VX_COLOR:DARK_PINK);
      tft.drawLine(cx-r, cy-r+o, cx+r, cy+r+o, (t==1)?VX_COLOR:DARK_PINK);
      tft.drawLine(cx-r+o, cy+r, cx+r+o, cy-r, (t==1)?VX_COLOR:DARK_PINK);
      tft.drawLine(cx-r, cy+r+o, cx+r, cy-r+o, (t==1)?VX_COLOR:DARK_PINK);
    }
    tft.drawPixel(cx, cy, WHITE);
  } else {
    tft.drawCircle(cx, cy, r+1, DARK_CYAN);
    tft.drawCircle(cx, cy, r,   VO_COLOR);
    tft.drawCircle(cx, cy, r-1, VO_COLOR);
    tft.drawCircle(cx, cy, r-2, WHITE);
    tft.drawPixel(cx-r/2, cy-r/2, WHITE);
  }
}

static int velhaCheckWin() {
  for (int i = 0; i < 3; i++) {
    if (velhaBoard[i][0] && velhaBoard[i][0]==velhaBoard[i][1] && velhaBoard[i][1]==velhaBoard[i][2]) return velhaBoard[i][0];
    if (velhaBoard[0][i] && velhaBoard[0][i]==velhaBoard[1][i] && velhaBoard[1][i]==velhaBoard[2][i]) return velhaBoard[0][i];
  }
  if (velhaBoard[0][0] && velhaBoard[0][0]==velhaBoard[1][1] && velhaBoard[1][1]==velhaBoard[2][2]) return velhaBoard[0][0];
  if (velhaBoard[0][2] && velhaBoard[0][2]==velhaBoard[1][1] && velhaBoard[1][1]==velhaBoard[2][0]) return velhaBoard[0][2];
  return 0;
}

static bool velhaIsFull() {
  for (int r = 0; r < 3; r++) for (int c = 0; c < 3; c++) if (!velhaBoard[r][c]) return false;
  return true;
}

static void velhaDrawWinLine(int winner) {
  uint16_t lc = (winner==1) ? VX_COLOR : VO_COLOR;
  for (int i = 0; i < 3; i++) {
    if (velhaBoard[i][0]==winner && velhaBoard[i][1]==winner && velhaBoard[i][2]==winner) {
      int y = VELHA_OY+i*VELHA_CELL+VELHA_CELL/2;
      for (int t=-2;t<=2;t++) tft.drawFastHLine(VELHA_OX+6,y+t,VELHA_SIZE-12,(t==0)?WHITE:lc);
      return;
    }
    if (velhaBoard[0][i]==winner && velhaBoard[1][i]==winner && velhaBoard[2][i]==winner) {
      int x = VELHA_OX+i*VELHA_CELL+VELHA_CELL/2;
      for (int t=-2;t<=2;t++) tft.drawFastVLine(x+t,VELHA_OY+6,VELHA_SIZE-12,(t==0)?WHITE:lc);
      return;
    }
  }
  if (velhaBoard[0][0]==winner && velhaBoard[1][1]==winner && velhaBoard[2][2]==winner) {
    for (int t=-2;t<=2;t++) tft.drawLine(VELHA_OX+8+t,VELHA_OY+8,VELHA_OX+VELHA_SIZE-8+t,VELHA_OY+VELHA_SIZE-8,(t==0)?WHITE:lc);
    return;
  }
  if (velhaBoard[0][2]==winner && velhaBoard[1][1]==winner && velhaBoard[2][0]==winner) {
    for (int t=-2;t<=2;t++) tft.drawLine(VELHA_OX+VELHA_SIZE-8+t,VELHA_OY+8,VELHA_OX+8+t,VELHA_OY+VELHA_SIZE-8,(t==0)?WHITE:lc);
    return;
  }
}

static void velhaShowFinalVictory(int winner) {
  int bw=SCREEN_W-30, bh=80, bx=15, by=SCREEN_H/2-bh/2;
  fillGradientV(bx,by,bw,bh,RGB(0,0,40),RGB(10,0,30));
  uint16_t col = (winner==1) ? VX_COLOR : VO_COLOR;
  drawNeonRect(bx,by,bw,bh,col,8);
  drawStar4(bx+10,by+10,4,COL_GOLD); drawStar4(bx+bw-10,by+10,4,COL_GOLD);
  drawStar4(bx+10,by+bh-10,4,COL_GOLD); drawStar4(bx+bw-10,by+bh-10,4,COL_GOLD);
  drawCenteredText(bx,by+4,bw,bh/2-4,(winner==1)?"VOCE VENCEU!":" CPU VENCEU!",2,col);
  drawCenteredText(bx,by+bh/2+2,bw,bh/2-8,(winner==1)?" PARABENS! ":"Tente novamente",1,GRAY);
  drawCenteredText(bx,by+bh-14,bw,12,"Voltando ao menu...",1,MIDGRAY);
}

static void velhaShowResult(int winner) {
  velhaOver = true;
  if (winner) velhaDrawWinLine(winner);
  if (winner==1) velhaWins[0]++;
  else if (winner==2) velhaWins[1]++;
  velhaDrawSidebar();

  if (velhaWins[0] >= VELHA_WIN_SCORE || velhaWins[1] >= VELHA_WIN_SCORE) {
    int seriesWinner = (velhaWins[0] >= VELHA_WIN_SCORE) ? 1 : 2;
    velhaShowFinalVictory(seriesWinner);
    velhaVictoryPending=true; velhaVictoryWinner=seriesWinner; velhaVictoryStartTime=millis();
    if (seriesWinner == 1) { /* Motor A/B escolhido na tela de seleção */ }
    return;
  }

  int bw=VELHA_SIZE-20, bh=58, bx=VELHA_OX+10, by=VELHA_OY+VELHA_SIZE/2-bh/2;
  fillGradientV(bx,by,bw,bh,RGB(0,0,35),RGB(8,0,25));
  uint16_t col = (winner==1)?VX_COLOR:(winner==2)?VO_COLOR:NEON_YELLOW;
  drawNeonRect(bx,by,bw,bh,col,7);
  const char *msg = (winner==1)?"VOCE GANHOU":(winner==2)?" CPU GANHOU":"  EMPATE!  ";
  drawCenteredText(bx,by+2,bw,bh-18,msg,2,col);
  drawCenteredText(bx,by+bh-14,bw,12,"Toque p/ proxima",1,GRAY);
  drawBackButton(NEON_CYAN);
}

static bool velhaPlayAt(int row, int col, int player) {
  velhaBoard[row][col] = player;
  velhaDrawPiece(col, row, player);
  int w = velhaCheckWin();
  if (w)              { velhaShowResult(w); return true; }
  if (velhaIsFull())  { velhaShowResult(0); return true; }
  return false;
}

static void velhaCpuPlay() {
  int r, c; cpuBestMove(r, c);
  if (r<0||c<0) return;
  delay(300);
  if (!velhaPlayAt(r, c, 2)) { velhaPlayer=1; velhaDrawSidebar(); }
}

// ─────────────────────────────────────────────────────────────────────────────
// INTERFACE PÚBLICA
// ─────────────────────────────────────────────────────────────────────────────
void velhaInit() {
  for (int r=0;r<3;r++) for (int c=0;c<3;c++) velhaBoard[r][c]=0;
  velhaPlayer=1; velhaOver=false;
  velhaDrawScene();
}

void velhaFullReset() {
  velhaWins[0]=0; velhaWins[1]=0;
  velhaVictoryPending=false; velhaDone=false;
  velhaInit();
}

void velhaLoop(unsigned long now) {
  bool justPressed = touchJustPressed();
  int  tx = touchX(), ty = touchY();

  if (velhaVictoryPending) {
    if (justPressed && isBackTouch(tx, ty)) { velhaDone = true; return; }
    if (now - velhaVictoryStartTime >= VICTORY_DELAY_MS) velhaDone = true;
    return;
  }

  if (justPressed && isBackTouch(tx, ty)) { velhaDone = true; return; }

  if (!velhaOver && velhaPlayer == 2) { velhaCpuPlay(); return; }

  if (justPressed) {
    if (velhaOver) {
      if (velhaVictoryPending) velhaFullReset();
      else velhaInit();
      return;
    }
    if (velhaPlayer != 1) return;
    if (tx < VELHA_OX || tx >= VELHA_OX + VELHA_SIZE) return;
    if (ty < VELHA_OY || ty >= VELHA_OY + VELHA_SIZE) return;
    int col = constrain((tx - VELHA_OX) / VELHA_CELL, 0, 2);
    int row = constrain((ty - VELHA_OY) / VELHA_CELL, 0, 2);
    if (velhaBoard[row][col]) return;
    if (!velhaPlayAt(row, col, 1)) { velhaPlayer = 2; velhaDrawSidebar(); }
  }
}

bool velhaIsDone()    { return velhaDone; }
bool velhaPlayerWon() { return velhaDone && (velhaVictoryWinner == 1); }
