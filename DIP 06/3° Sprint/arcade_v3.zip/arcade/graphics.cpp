/*
 * graphics.cpp — Implementação das primitivas visuais
 */

#include "graphics.h"

// ─────────────────────────────────────────────────────────────────────────────
// CAMPO ESTRELADO em PROGMEM (economiza ~150 bytes de RAM vs arrays normais)
// ─────────────────────────────────────────────────────────────────────────────
const uint16_t STAR_X[NUM_STARS] PROGMEM = {
   12, 30, 55, 80,105,130,160,185,210,240,
  265,290,310,  5, 45, 70, 95,120,150,175,
  200,230,255,280,305,315, 20, 50, 75,100,
  125,155,180,205,235,260,285,308,  8, 35,
   60, 90,115,145,170,195,225,250,275,302
};
const uint8_t STAR_Y[NUM_STARS] PROGMEM = {
   10, 25, 15, 35, 20, 45, 10, 30, 50, 18,
   38, 22, 42, 60, 55, 70, 65, 80, 58, 72,
   68, 75, 62, 85, 78, 90,100, 95,110,105,
  120, 98,112,108,115,102,125,118,140,135,
  150,145,160,138,152,148,155,142,165,158
};

// ─────────────────────────────────────────────────────────────────────────────
// GRADIENTE VERTICAL
// ─────────────────────────────────────────────────────────────────────────────
void fillGradientV(int x, int y, int w, int h, uint16_t c1, uint16_t c2) {
  if (h <= 0 || w <= 0) return;
  for (int i = 0; i < h; i++) {
    int r = ((c1>>11)&0x1F) + (int)(((c2>>11)&0x1F) - ((c1>>11)&0x1F)) * i / h;
    int g = ((c1>>5) &0x3F) + (int)(((c2>>5) &0x3F) - ((c1>>5) &0x3F)) * i / h;
    int b = (c1&0x1F)       + (int)( (c2&0x1F)       - (c1&0x1F))       * i / h;
    tft.drawFastHLine(x, y+i, w,
      ((uint16_t)r<<11)|((uint16_t)g<<5)|(uint16_t)b);
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// RETÂNGULO NEON (brilho em camadas)
// ─────────────────────────────────────────────────────────────────────────────
void drawNeonRect(int x, int y, int w, int h, uint16_t col, int radius) {
  uint16_t dim = ((((col>>11)&0x1F)/3)<<11) |
                 (((((col>>5)&0x3F)/3))<<5) |
                 ((col&0x1F)/3);
  tft.drawRoundRect(x-1, y-1, w+2, h+2, radius+1, dim);
  tft.drawRoundRect(x,   y,   w,   h,   radius,   col);
  tft.drawRoundRect(x+1, y+1, w-2, h-2, radius-1, dim);
}

// ─────────────────────────────────────────────────────────────────────────────
// TEXTO CENTRALIZADO numa caixa
// ─────────────────────────────────────────────────────────────────────────────
void drawCenteredText(int bx, int by, int bw, int bh,
                      const char *txt, int sz, uint16_t col) {
  tft.setTextSize(sz);
  tft.setTextColor(col);
  tft.setCursor(bx + (bw - (int)strlen(txt)*6*sz)/2,
                by + (bh - 8*sz)/2);
  tft.print(txt);
}

// ─────────────────────────────────────────────────────────────────────────────
// DECORAÇÕES
// ─────────────────────────────────────────────────────────────────────────────
void drawStar4(int cx, int cy, int r, uint16_t col) {
  tft.drawLine(cx-r, cy,   cx+r, cy,   col);
  tft.drawLine(cx,   cy-r, cx,   cy+r, col);
}

void drawDiamond(int cx, int cy, int r, uint16_t col) {
  tft.drawLine(cx,   cy-r, cx+r, cy,   col);
  tft.drawLine(cx+r, cy,   cx,   cy+r, col);
  tft.drawLine(cx,   cy+r, cx-r, cy,   col);
  tft.drawLine(cx-r, cy,   cx,   cy-r, col);
}

void drawStarfield() {
  for (int i = 0; i < NUM_STARS; i++) {
    // Leitura de PROGMEM
    uint16_t sx = pgm_read_word(&STAR_X[i]);
    uint8_t  sy = pgm_read_byte(&STAR_Y[i]);
    uint8_t b = (i%3==0) ? 0x1F : (i%3==1) ? 0x10 : 0x08;
    uint16_t col = ((uint16_t)b<<11) | ((uint16_t)(b*2)<<5) | b;
    tft.drawPixel(sx, sy, col);
    if (i%5==0) tft.drawPixel(sx+1, sy, col);
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// BOTÃO VOLTAR
// ─────────────────────────────────────────────────────────────────────────────
void drawBackButton(uint16_t accentCol) {
  fillGradientV(BACK_X, BACK_Y, BACK_W, BACK_H, RGB(40,0,20), RGB(15,0,8));
  drawNeonRect(BACK_X, BACK_Y, BACK_W, BACK_H, accentCol, 4);
  tft.fillTriangle(BACK_X+6,  BACK_Y+BACK_H/2,
                   BACK_X+13, BACK_Y+5,
                   BACK_X+13, BACK_Y+BACK_H-5, accentCol);
  tft.setTextSize(2); tft.setTextColor(WHITE);
  tft.setCursor(BACK_X+17, BACK_Y+5);
  tft.print("BACK");
}

bool isBackTouch(int tx, int ty) {
  // touchX() já retorna coordenadas mapeadas (0..SCREEN_W-1),
  // sem inversão adicional.
  return (tx >= BACK_X && tx < BACK_X + BACK_W &&
          ty >= BACK_Y && ty < BACK_Y + BACK_H);
}
