/*
 * quiz.cpp — Jogo de Quiz
 */

#include "quiz.h"
#include "touch.h"
#include "buttons.h"

// ─────────────────────────────────────────────────────────────────────────────
// CONFIGURAÇÃO
// ─────────────────────────────────────────────────────────────────────────────
#define QUIZ_TOTAL       5
#define QUIZ_WIN         3
#define QUIZ_HUD_H       28
#define QUIZ_Q_Y         30
#define QUIZ_Q_H         70
#define QUIZ_ANS_Y       108
#define FEEDBACK_MS      900
#define VICTORY_DELAY_MS 3000

#define QUIZ_BTN_W  150
#define QUIZ_BTN_H   52
#define QUIZ_BTN_GAP  4
#define QUIZ_BTN_X0   2
#define QUIZ_BTN_X1  (QUIZ_BTN_X0 + QUIZ_BTN_W + QUIZ_BTN_GAP)
#define QUIZ_BTN_Y0  QUIZ_ANS_Y
#define QUIZ_BTN_Y1  (QUIZ_ANS_Y + QUIZ_BTN_H + QUIZ_BTN_GAP)

// ─────────────────────────────────────────────────────────────────────────────
// BANCO DE PERGUNTAS EM PROGMEM (12 perguntas, sorteadas 5 por partida)
// ─────────────────────────────────────────────────────────────────────────────
#define QUIZ_BANK_SIZE 12

const char qP00[] PROGMEM = "Qual planet. mais perto do sol?";
const char qA00[] PROGMEM = "Venus";
const char qB00[] PROGMEM = "Mercurio";
const char qC00[] PROGMEM = "Marte";
const char qD00[] PROGMEM = "Terra";

const char qP01[] PROGMEM = "Quantos lados tem um hexagono?";
const char qA01[] PROGMEM = "5";
const char qB01[] PROGMEM = "7";
const char qC01[] PROGMEM = "6";
const char qD01[] PROGMEM = "8";

const char qP02[] PROGMEM = "Qual o maior oceano?";
const char qA02[] PROGMEM = "Atlantico";
const char qB02[] PROGMEM = "Indico";
const char qC02[] PROGMEM = "Artico";
const char qD02[] PROGMEM = "Pacifico";

const char qP03[] PROGMEM = "H2O e a formula de que?";
const char qA03[] PROGMEM = "Sal";
const char qB03[] PROGMEM = "Agua";
const char qC03[] PROGMEM = "Oxigenio";
const char qD03[] PROGMEM = "Hidrogenio";

const char qP04[] PROGMEM = "Quantos continentes ha?";
const char qA04[] PROGMEM = "5";
const char qB04[] PROGMEM = "8";
const char qC04[] PROGMEM = "7";
const char qD04[] PROGMEM = "6";

const char qP05[] PROGMEM = "Qual a capital do Brasil?";
const char qA05[] PROGMEM = "Sao Paulo";
const char qB05[] PROGMEM = "Brasilia";
const char qC05[] PROGMEM = "Rio";
const char qD05[] PROGMEM = "Salvador";

const char qP06[] PROGMEM = "Qual animal mais rapido?";
const char qA06[] PROGMEM = "Leao";
const char qB06[] PROGMEM = "Guepardo";
const char qC06[] PROGMEM = "Cavalo";
const char qD06[] PROGMEM = "Aguia";

const char qP07[] PROGMEM = "Quantas horas tem 1 dia?";
const char qA07[] PROGMEM = "12";
const char qB07[] PROGMEM = "48";
const char qC07[] PROGMEM = "36";
const char qD07[] PROGMEM = "24";

const char qP08[] PROGMEM = "Qual o menor pais do mundo?";
const char qA08[] PROGMEM = "Monaco";
const char qB08[] PROGMEM = "Vaticano";
const char qC08[] PROGMEM = "Andorra";
const char qD08[] PROGMEM = "Nauru";

const char qP09[] PROGMEM = "Quem escreveu Dom Quixote?";
const char qA09[] PROGMEM = "Cervantes";
const char qB09[] PROGMEM = "Shakespeare";
const char qC09[] PROGMEM = "Dante";
const char qD09[] PROGMEM = "Camoes";

const char qP10[] PROGMEM = "Quantos anos tem 1 seculo?";
const char qA10[] PROGMEM = "10";
const char qB10[] PROGMEM = "1000";
const char qC10[] PROGMEM = "50";
const char qD10[] PROGMEM = "100";

const char qP11[] PROGMEM = "Qual elemento quimico e Au?";
const char qA11[] PROGMEM = "Prata";
const char qB11[] PROGMEM = "Ouro";
const char qC11[] PROGMEM = "Cobre";
const char qD11[] PROGMEM = "Ferro";

// Struct com ponteiros para PROGMEM
struct QuizEntry {
  const char *q, *a, *b, *c, *d;
  uint8_t correct; // 0=A, 1=B, 2=C, 3=D
};

const QuizEntry QUIZ_BANK[QUIZ_BANK_SIZE] PROGMEM = {
  {qP00,qA00,qB00,qC00,qD00, 1},
  {qP01,qA01,qB01,qC01,qD01, 2},
  {qP02,qA02,qB02,qC02,qD02, 3},
  {qP03,qA03,qB03,qC03,qD03, 1},
  {qP04,qA04,qB04,qC04,qD04, 2},
  {qP05,qA05,qB05,qC05,qD05, 1},
  {qP06,qA06,qB06,qC06,qD06, 1},
  {qP07,qA07,qB07,qC07,qD07, 3},
  {qP08,qA08,qB08,qC08,qD08, 1},
  {qP09,qA09,qB09,qC09,qD09, 0},
  {qP10,qA10,qB10,qC10,qD10, 3},
  {qP11,qA11,qB11,qC11,qD11, 1}
};

// ─────────────────────────────────────────────────────────────────────────────
// ESTADO INTERNO
// ─────────────────────────────────────────────────────────────────────────────
static int  quizOrder[QUIZ_BANK_SIZE];
static int  quizCurrent          = 0;
static int  quizScore            = 0;
static int  quizAnswered         = -1;
static bool quizFeedback         = false;
static unsigned long quizFeedbackTimer = 0;
static bool quizOver             = false;
static bool quizDone             = false;

static bool          quizVictoryPending   = false;
static int           quizVictoryWinner    = 0;
static unsigned long quizVictoryStartTime = 0;

static char qBuf[34]; // buffer para leitura de PROGMEM

// Paletas dos botões
static const uint16_t QUIZ_BTN_COLORS[4] = {NEON_CYAN, NEON_YELLOW, NEON_GREEN, NEON_ORANGE};
static const char     QUIZ_BTN_LABELS[4][2] = {"A","B","C","D"};

// ─────────────────────────────────────────────────────────────────────────────
// HELPERS PROGMEM
// ─────────────────────────────────────────────────────────────────────────────
static void quizReadStr(const char *pgmPtr) {
  strncpy_P(qBuf, pgmPtr, sizeof(qBuf)-1);
  qBuf[sizeof(qBuf)-1] = '\0';
}

static const char* quizGetField(int qIdx, int field) {
  // field: 0=q, 1=a, 2=b, 3=c, 4=d
  const char * const *base = (const char * const *)&QUIZ_BANK[qIdx];
  return (const char*)pgm_read_ptr(base + field);
}

static uint8_t quizGetCorrect(int qIdx) {
  return pgm_read_byte(&QUIZ_BANK[qIdx].correct);
}

// ─────────────────────────────────────────────────────────────────────────────
// SHUFFLE Fisher-Yates com seed baseada em millis()
// ─────────────────────────────────────────────────────────────────────────────
static void quizShuffle() {
  for (int i=0;i<QUIZ_BANK_SIZE;i++) quizOrder[i]=i;
  uint16_t seed = (uint16_t)(millis() & 0xFFFF);
  for (int i=QUIZ_BANK_SIZE-1;i>0;i--) {
    seed = seed*6364+1442;
    int j = seed%(i+1);
    int tmp=quizOrder[i]; quizOrder[i]=quizOrder[j]; quizOrder[j]=tmp;
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// LAYOUT DE BOTÕES
// ─────────────────────────────────────────────────────────────────────────────
static int quizBtnX(int i) { return (i%2==0) ? QUIZ_BTN_X0 : QUIZ_BTN_X1; }
static int quizBtnY(int i) { return (i/2==0) ? QUIZ_BTN_Y0 : QUIZ_BTN_Y1; }

// ─────────────────────────────────────────────────────────────────────────────
// DESENHO
// ─────────────────────────────────────────────────────────────────────────────
static void quizDrawHUD() {
  fillGradientV(0,0,SCREEN_W,QUIZ_HUD_H,RGB(20,10,0),RGB(8,4,0));
  tft.drawFastHLine(0,QUIZ_HUD_H,SCREEN_W,NEON_YELLOW);
  tft.setTextSize(1); tft.setTextColor(NEON_YELLOW);
  tft.setCursor(BACK_W+8,4);  tft.print("QUIZ");
  tft.setTextColor(NEON_GREEN);
  tft.setCursor(BACK_W+8,15); tft.print("Acertos: "); tft.print(quizScore);
  tft.setTextColor(MIDGRAY);
  tft.setCursor(220,4);  tft.print("Q ");tft.print(quizCurrent+1);tft.print("/");tft.print(QUIZ_TOTAL);
  tft.setCursor(220,15); tft.print("Para vencer: ");tft.print(QUIZ_WIN);
  drawBackButton(NEON_YELLOW);
}

static void quizDrawQuestion() {
  int qIdx = quizOrder[quizCurrent];
  tft.fillRect(2,QUIZ_Q_Y,SCREEN_W-4,QUIZ_Q_H,RGB(0,6,18));
  drawNeonRect(2,QUIZ_Q_Y,SCREEN_W-4,QUIZ_Q_H,NEON_BLUE,5);

  quizReadStr(quizGetField(qIdx,0));
  int len = strlen(qBuf);
  tft.setTextSize(1); tft.setTextColor(WHITE);

  if (len <= 26) {
    int tx = 6+(SCREEN_W-12-(int)len*6)/2;
    tft.setCursor(max(6,tx), QUIZ_Q_Y+(QUIZ_Q_H/2)-4);
    tft.print(qBuf);
  } else {
    // Quebra na palavra mais próxima do meio
    int split=16;
    for (int i=len/2;i>0;i--) { if (qBuf[i]==' ') { split=i; break; } }
    char line1[34], line2[34];
    strncpy(line1,qBuf,split); line1[split]='\0';
    strncpy(line2,qBuf+split+1,sizeof(line2)-1); line2[sizeof(line2)-1]='\0';
    tft.setCursor(6+(SCREEN_W-12-(int)strlen(line1)*6)/2, QUIZ_Q_Y+QUIZ_Q_H/2-10);
    tft.print(line1);
    tft.setCursor(6+(SCREEN_W-12-(int)strlen(line2)*6)/2, QUIZ_Q_Y+QUIZ_Q_H/2+2);
    tft.print(line2);
  }
}

static void quizDrawAnswers(int highlight=-1, int correct=-1) {
  int qIdx = quizOrder[quizCurrent];
  for (int i=0;i<4;i++) {
    int bx=quizBtnX(i), by=quizBtnY(i);
    uint16_t bgCol, neonCol, txtCol;
    if (correct>=0) {
      if (i==correct)                         { bgCol=RGB(0,30,0);  neonCol=NEON_GREEN; txtCol=NEON_GREEN; }
      else if (i==highlight && i!=correct)    { bgCol=RGB(30,0,0);  neonCol=NEON_PINK;  txtCol=NEON_PINK; }
      else                                    { bgCol=DARKGRAY;     neonCol=MIDGRAY;    txtCol=MIDGRAY; }
    } else {
      bgCol=RGB(0,4,12); neonCol=QUIZ_BTN_COLORS[i]; txtCol=QUIZ_BTN_COLORS[i];
    }
    tft.fillRoundRect(bx,by,QUIZ_BTN_W,QUIZ_BTN_H,5,bgCol);
    drawNeonRect(bx,by,QUIZ_BTN_W,QUIZ_BTN_H,neonCol,5);
    tft.setTextSize(2); tft.setTextColor(neonCol);
    tft.setCursor(bx+5,by+6); tft.print(QUIZ_BTN_LABELS[i]);
    quizReadStr(quizGetField(qIdx,i+1));
    tft.setTextSize(1); tft.setTextColor(txtCol);
    int tx2=bx+20+(QUIZ_BTN_W-20-(int)strlen(qBuf)*6)/2;
    tft.setCursor(max(bx+20,tx2), by+QUIZ_BTN_H/2-4);
    tft.print(qBuf);
  }
}

static void quizShowFinalVictory(int winner) {
  int bw=SCREEN_W-30, bh=80, bx=15, by=SCREEN_H/2-bh/2;
  fillGradientV(bx,by,bw,bh,RGB(20,10,0),RGB(8,4,0));
  uint16_t col=(winner==1)?NEON_GREEN:NEON_PINK;
  drawNeonRect(bx,by,bw,bh,col,8);
  drawStar4(bx+10,by+10,4,COL_GOLD); drawStar4(bx+bw-10,by+10,4,COL_GOLD);
  drawStar4(bx+10,by+bh-10,4,COL_GOLD); drawStar4(bx+bw-10,by+bh-10,4,COL_GOLD);
  drawCenteredText(bx,by+4,bw,bh/2-4,(winner==1)?"VOCE VENCEU!":"GAME OVER!",2,col);
  char scoreBuf[24];
  snprintf(scoreBuf,sizeof(scoreBuf),"Acertos: %d/%d",quizScore,QUIZ_TOTAL);
  drawCenteredText(bx,by+bh/2+2,bw,bh/2-8,scoreBuf,1,GRAY);
  drawCenteredText(bx,by+bh-14,bw,12,"Voltando ao menu...",1,MIDGRAY);
}

static void quizDrawScreen() {
  tft.fillScreen(BLACK);
  quizDrawHUD();
  quizDrawQuestion();
  quizDrawAnswers();
}

// ─────────────────────────────────────────────────────────────────────────────
// LÓGICA
// ─────────────────────────────────────────────────────────────────────────────
static void quizAdvance() {
  quizFeedback=false; quizAnswered=-1;
  quizCurrent++;
  int remaining  = QUIZ_TOTAL - quizCurrent;
  bool playerWon = (quizScore >= QUIZ_WIN);
  bool impossible= (quizScore + remaining < QUIZ_WIN);
  bool allDone   = (quizCurrent >= QUIZ_TOTAL);

  if (playerWon||impossible||allDone) {
    quizOver=true;
    quizVictoryWinner=(playerWon?1:2);
    quizVictoryPending=true; quizVictoryStartTime=millis();
    quizShowFinalVictory(quizVictoryWinner);
    if (playerWon) { /* Motor A/B escolhido na tela de seleção */ }
    return;
  }
  quizDrawHUD(); quizDrawQuestion(); quizDrawAnswers();
}

// ─────────────────────────────────────────────────────────────────────────────
// INTERFACE PÚBLICA
// ─────────────────────────────────────────────────────────────────────────────
void quizInit() {
  quizShuffle();
  quizCurrent=0; quizScore=0; quizAnswered=-1;
  quizFeedback=false; quizOver=false;
  quizVictoryPending=false; quizDone=false;
  quizDrawScreen();
}

void quizLoop(unsigned long now) {
  if (quizVictoryPending) {
    if (touchJustPressed() && isBackTouch(touchX(), touchY())) {
      quizDone = true; return;
    }
    if (now - quizVictoryStartTime >= VICTORY_DELAY_MS) quizDone = true;
    return;
  }

  if (quizFeedback) {
    if (now - quizFeedbackTimer >= FEEDBACK_MS) quizAdvance();
    return;
  }

  // Helper local para processar escolha de resposta (toque ou botão)
  auto processAnswer = [&](int i) {
    int qIdx    = quizOrder[quizCurrent];
    int correct = quizGetCorrect(qIdx);
    if (i == correct) quizScore++;
    quizDrawAnswers(i, correct);
    quizFeedback = true; quizFeedbackTimer = millis();
  };

  // Botões físicos: BTN1=A, BTN2=B, BTN3=C, BTN4=D
  for (uint8_t b = 1; b <= 4; b++) {
    if (btnJustPressed(b)) { processAnswer(b - 1); return; }
  }

  if (!touchJustPressed()) return;
  int tx = touchX(), ty = touchY();

  if (isBackTouch(tx, ty)) { quizDone = true; return; }

  for (int i = 0; i < 4; i++) {
    int bx = quizBtnX(i), by = quizBtnY(i);
    if (tx >= bx && tx < bx+QUIZ_BTN_W && ty >= by && ty < by+QUIZ_BTN_H) {
      processAnswer(i); return;
    }
  }
}

bool quizIsDone()    { return quizDone; }
bool quizPlayerWon() { return quizDone && (quizVictoryWinner == 1); }
