#pragma once
/*
 * touch.h — Leitura, calibração e detecção de borda do touch resistivo
 *
 * MODELO DE INPUT:
 *   touchUpdate() deve ser chamado UMA VEZ por loop().
 *   Após isso, use:
 *     touchIsPressed()   → dedo está no display agora
 *     touchJustPressed() → borda de subida (falso → verdadeiro) neste frame
 *     touchJustReleased()→ borda de descida neste frame
 *     touchX(), touchY() → coordenadas do toque atual (ou do último)
 *
 *   touchJustPressed() já inclui debounce interno de TOUCH_DEBOUNCE_MS.
 *   Os módulos NÃO precisam de debounce próprio — basta checar justPressed.
 *
 * CALIBRAÇÃO:
 *   Salva/lê da EEPROM. Rotina interativa de 4 cantos via touchRunCalibration().
 */

#include <TouchScreen.h>
#include <EEPROM.h>

// ─────────────────────────────────────────────────────────────────────────────
// PINOS
// ─────────────────────────────────────────────────────────────────────────────
#define YP A1
#define XM A2
#define YM 7
#define XP 6

// ─────────────────────────────────────────────────────────────────────────────
// CALIBRAÇÃO PADRÃO (fallback se EEPROM vazia)
// ─────────────────────────────────────────────────────────────────────────────
#define TS_MINX_DEFAULT 120
#define TS_MAXX_DEFAULT 900
#define TS_MINY_DEFAULT  70
#define TS_MAXY_DEFAULT 920

// Limiar de pressão — aumentado para rejeitar leituras espúrias na borda
#define MINPRESSURE  30
#define MAXPRESSURE 1000

// Debounce único e centralizado (ms entre dois "justPressed" válidos)
#define TOUCH_DEBOUNCE_MS 80

// ─────────────────────────────────────────────────────────────────────────────
// EEPROM
// ─────────────────────────────────────────────────────────────────────────────
#define EEPROM_ADDR_MAGIC 0
#define EEPROM_ADDR_DATA  2
#define EEPROM_MAGIC      0xA5

struct TouchCalib {
  int minX, maxX, minY, maxY;
};

extern TouchCalib g_calib;
extern TouchScreen ts;

// ─────────────────────────────────────────────────────────────────────────────
// CALIBRAÇÃO
// ─────────────────────────────────────────────────────────────────────────────
void touchLoadCalib();
void touchSaveCalib(const TouchCalib &c);
void touchRunCalibration();

// ─────────────────────────────────────────────────────────────────────────────
// API DE INPUT — chame touchUpdate() uma vez por frame, depois consulte:
// ─────────────────────────────────────────────────────────────────────────────
void touchUpdate();            // lê hardware e atualiza estado interno
bool touchIsPressed();         // dedo no display agora
bool touchJustPressed();       // borda de subida com debounce neste frame
bool touchJustReleased();      // borda de descida neste frame
int  touchX();                 // coordenada X atual (válida se isPressed)
int  touchY();                 // coordenada Y atual
