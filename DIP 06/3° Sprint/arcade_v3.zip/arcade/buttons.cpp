/*
 * buttons.cpp — 4 botões físicos com debounce centralizado
 */

#include "buttons.h"

static const uint8_t BTN_PINS[BTN_COUNT] = {
  BTN1_PIN, BTN2_PIN, BTN3_PIN, BTN4_PIN
};

// Estado por botão
static bool          _pressed[BTN_COUNT]       = {};
static bool          _justPressed[BTN_COUNT]   = {};
static bool          _prevPressed[BTN_COUNT]   = {};
static unsigned long _lastPressTime[BTN_COUNT] = {};

void buttonsInit() {
  for (uint8_t i = 0; i < BTN_COUNT; i++) {
    pinMode(BTN_PINS[i], INPUT_PULLUP);
    _pressed[i]      = false;
    _justPressed[i]  = false;
    _prevPressed[i]  = false;
    _lastPressTime[i]= 0;
  }
}

void buttonsUpdate() {
  unsigned long now = millis();
  for (uint8_t i = 0; i < BTN_COUNT; i++) {
    _prevPressed[i] = _pressed[i];
    // INPUT_PULLUP: LOW = pressionado
    _pressed[i] = (digitalRead(BTN_PINS[i]) == LOW);

    bool risingEdge = !_prevPressed[i] && _pressed[i];
    bool debounceOk = (now - _lastPressTime[i]) >= BTN_DEBOUNCE_MS;

    if (risingEdge && debounceOk) {
      _justPressed[i]  = true;
      _lastPressTime[i] = now;
    } else {
      _justPressed[i] = false;
    }
  }
}

bool btnPressed(uint8_t n) {
  if (n < 1 || n > BTN_COUNT) return false;
  return _pressed[n - 1];
}

bool btnJustPressed(uint8_t n) {
  if (n < 1 || n > BTN_COUNT) return false;
  return _justPressed[n - 1];
}
