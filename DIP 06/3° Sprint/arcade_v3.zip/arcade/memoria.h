#pragma once
/*
 * memoria.h — Jogo da Memória 4×4 (8 pares)
 */

#include <Arduino.h>
#include "graphics.h"

void memInit();
void memLoop(unsigned long now);
bool memIsDone();
bool memPlayerWon();  // true somente se o jogador completou o jogo
