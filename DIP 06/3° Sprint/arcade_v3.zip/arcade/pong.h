#pragma once
/*
 * pong.h — Jogo Pong vs CPU
 *
 * Melhorias v11:
 * - Física da bola em ponto fixo (x100) — elimina float no loop principal
 * - IA com fator de erro aleatório para ser menos previsível
 * - CPU só reage quando a bola está na metade dela
 */

#include <Arduino.h>
#include "graphics.h"

// ─────────────────────────────────────────────────────────────────────────────
// CONSTANTES DO JOGO
// ─────────────────────────────────────────────────────────────────────────────
#define PADDLE_W       10
#define PADDLE_H       56
#define BALL_R          5
#define PLAY_Y1        28
#define PLAY_H         (SCREEN_H - PLAY_Y1)
#define HUD_Y          27
#define ARENA_BG       RGB(0,2,8)

// Velocidades em ponto fixo (×100)
#define BALL_VX_INIT   350    //  3.50 px/frame
#define BALL_VY_INIT   220    //  2.20 px/frame
#define BALL_VX_MAX    700    //  7.00 px/frame
#define BALL_VY_MAX    550    //  5.50 px/frame
#define BALL_ACCEL     104    //  fator ×1.04 (104/100)

// IA — velocidade base e margem de erro
#define CPU_SPEED       3     // px/frame máximo
#define CPU_ERROR_MAX   18   // px de erro aleatório no target

#define WIN_SCORE       4
#define P1_COLOR        NEON_CYAN
#define P2_COLOR        NEON_PINK
#define BALL_COL        NEON_YELLOW

#define PONG_INTERVAL     18   // ms por frame
#define VICTORY_DELAY_MS  3000
#define POINT_DELAY_MS    400

// ─────────────────────────────────────────────────────────────────────────────
// INTERFACE PÚBLICA
// ─────────────────────────────────────────────────────────────────────────────
void pongInit();
void pongLoop(unsigned long now);   // usa touchIsPressed/touchJustPressed internamente
bool pongIsDone();
bool pongPlayerWon();  // true somente se o jogador (p1) venceu
