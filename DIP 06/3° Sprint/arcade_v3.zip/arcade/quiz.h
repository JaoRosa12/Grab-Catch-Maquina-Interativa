#pragma once
/*
 * quiz.h — Jogo de Quiz, melhor de 5 perguntas
 * Perguntas em PROGMEM para economizar RAM.
 */

#include <Arduino.h>
#include <avr/pgmspace.h>
#include "graphics.h"

void quizInit();
void quizLoop(unsigned long now);
bool quizIsDone();
bool quizPlayerWon();  // true somente se o jogador venceu o quiz
