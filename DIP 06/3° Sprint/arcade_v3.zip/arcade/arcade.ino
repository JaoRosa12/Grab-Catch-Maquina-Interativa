/*
 * ╔══════════════════════════════════════════════════════════════════╗
 * ║   TFT Shield 2.4" — ARCADE NEON EDITION v14                    ║
 * ║   Hardware : MCUFRIEND_kbv + TouchScreen (74HC245)              ║
 * ║   Rotação  : Paisagem 320 × 240 px                              ║
 * ╚══════════════════════════════════════════════════════════════════╝
 *
 * MUDANÇA v13 — Integração Serial com Arduino Uno (Motor):
 *
 *   Serial1 (TX1, pino 18) @ 9600 bps → Arduino Uno (RX, pino 10)
 *
 *   Protocolo:
 *     Mega → Uno: 'A'  — jogador escolheu Pirulito (Motor A)
 *     Mega → Uno: 'B'  — jogador escolheu Bala     (Motor B)
 *
 *   Após vencer qualquer jogo, o Mega entra no estado STATE_MOTOR_SELECT:
 *   exibe dois botões na tela (Motor A / Motor B). O toque envia o comando
 *   correspondente via Serial1 e retorna ao menu.
 *
 * ESTRUTURA DE ARQUIVOS:
 *   arcade.ino     ← setup / loop / despacho de estado
 *   graphics.h/cpp ← primitivas visuais, cores, starfield (PROGMEM)
 *   touch.h/cpp    ← leitura + borda + calibração EEPROM
 *   menu.h/cpp     ← menu principal e ícones
 *   pong.h/cpp     ← Pong vs CPU (ponto fixo, IA com erro aleatório)
 *   velha.h/cpp    ← Jogo da Velha vs CPU (Minimax)
 *   quiz.h/cpp     ← Quiz melhor de 5 (strings em PROGMEM)
 *   memoria.h/cpp  ← Jogo da Memória 4×4
 */

#include <MCUFRIEND_kbv.h>
#include "graphics.h"
#include "touch.h"
#include "buttons.h"
#include "menu.h"
#include "pong.h"
#include "velha.h"
#include "quiz.h"
#include "memoria.h"

// ─────────────────────────────────────────────────────────────────────────────
// DISPLAY — instância global compartilhada via extern nos módulos
// ─────────────────────────────────────────────────────────────────────────────
MCUFRIEND_kbv tft;

// ─────────────────────────────────────────────────────────────────────────────
// MÁQUINA DE ESTADOS
// ─────────────────────────────────────────────────────────────────────────────
enum GameState {
  STATE_MENU,
  STATE_PONG,
  STATE_VELHA,
  STATE_QUIZ,
  STATE_MEMORIA,
  STATE_MOTOR_SELECT   // ← tela de escolha de motor após vitória
};
static GameState currentState = STATE_MENU;

// ─────────────────────────────────────────────────────────────────────────────
// TELA DE SELEÇÃO DE MOTOR
// Layout: título centralizado + dois botões lado a lado
//   [ PIRULITO  ]   [   BALA    ]
// ─────────────────────────────────────────────────────────────────────────────
#define MBTN_W   130
#define MBTN_H    64
#define MBTN_Y   130
#define MBTN_AX    10
#define MBTN_BX   180

static void drawMotorSelectScreen() {
  tft.fillScreen(BLACK);
  drawStarfield();

  // Título
  tft.setTextSize(2);
  tft.setTextColor(NEON_YELLOW);
  tft.setCursor(30, 20);
  tft.print(F("VOCE VENCEU!"));

  tft.setTextSize(1);
  tft.setTextColor(WHITE);
  tft.setCursor(52, 50);
  tft.print(F("Escolha seu premio:"));

  tft.setTextSize(1);
  tft.setTextColor(MIDGRAY);
  tft.setCursor(30, 70);
  tft.print(F("Qual motor deseja girar?"));

  // Botao Motor A
  drawNeonRect(MBTN_AX, MBTN_Y, MBTN_W, MBTN_H, NEON_CYAN, 6);
  tft.setTextSize(2);
  tft.setTextColor(NEON_CYAN);
  tft.setCursor(MBTN_AX + 22, MBTN_Y + 12);
  tft.print(F("PIRU-"));
  tft.setCursor(MBTN_AX + 10, MBTN_Y + 36);
  tft.print(F("LITO"));

  // Botao Motor B
  drawNeonRect(MBTN_BX, MBTN_Y, MBTN_W, MBTN_H, NEON_PINK, 6);
  tft.setTextSize(2);
  tft.setTextColor(NEON_PINK);
  tft.setCursor(MBTN_BX + 22, MBTN_Y + 12);
  tft.print(F("BALA"));
}

// Retorna 'A', 'B', ou 0 se não tocou em nenhum botão
static char motorSelectCheck(int tx, int ty) {
  // O eixo X e mapeado invertido no touch (SCREEN_W->0), entao
  // desinverte para comparar com as coordenadas de desenho dos botoes.
  int txM = SCREEN_W - tx;
  if (ty >= MBTN_Y && ty <= MBTN_Y + MBTN_H) {
    if (txM >= MBTN_AX && txM <= MBTN_AX + MBTN_W) return 'A';
    if (txM >= MBTN_BX && txM <= MBTN_BX + MBTN_W) return 'B';
  }
  return 0;
}

// ─────────────────────────────────────────────────────────────────────────────
// TRANSIÇÃO PARA SELEÇÃO DE MOTOR (chamada quando jogo termina com vitória)
// ─────────────────────────────────────────────────────────────────────────────
static unsigned long motorSelectEnterTime = 0;
#define MOTOR_SELECT_GUARD_MS 400

static void enterMotorSelect() {
  currentState = STATE_MOTOR_SELECT;
  motorSelectEnterTime = millis();
  drawMotorSelectScreen();
}

// ─────────────────────────────────────────────────────────────────────────────
// SETUP
// ─────────────────────────────────────────────────────────────────────────────
void setup() {
  Serial1.begin(9600);   // TX1 (pino 18) → Arduino Uno RX (pino 10)
  buttonsInit();         // 4 botões físicos (pinos 22-25)

  uint16_t id = tft.readID();
  tft.begin(id);
  tft.setRotation(1);
  tft.fillScreen(BLACK);

  touchLoadCalib();

  // Segurar o touch no boot → entra na calibração
  {
    TSPoint p = ts.getPoint();
    pinMode(YP, OUTPUT); pinMode(XM, OUTPUT);
    digitalWrite(YP, HIGH); digitalWrite(XM, HIGH);
    if (p.z >= MINPRESSURE && p.z <= MAXPRESSURE) {
      touchRunCalibration();
    }
  }

  drawMenu();
}

// ─────────────────────────────────────────────────────────────────────────────
// LOOP
// ─────────────────────────────────────────────────────────────────────────────
void loop() {
  // Uma única leitura do hardware por frame — atualiza todas as flags
  touchUpdate();
  buttonsUpdate();   // lê os 4 botões físicos

  unsigned long now = millis();

  switch (currentState) {

    // ── MENU ────────────────────────────────────────────────────────────────
    case STATE_MENU:
      // Touch na tela
      if (touchJustPressed()) {
        int btn = checkMenuTouch(touchX(), touchY());
        if (btn == 1) { currentState = STATE_PONG;    pongInit();       }
        if (btn == 2) { currentState = STATE_VELHA;   velhaFullReset(); }
        if (btn == 3) { currentState = STATE_QUIZ;    quizInit();       }
        if (btn == 4) { currentState = STATE_MEMORIA; memInit();        }
      }
      // Botões físicos: BTN1=Pong, BTN2=Velha, BTN3=Quiz, BTN4=Memória
      if (btnJustPressed(1)) { currentState = STATE_PONG;    pongInit();       }
      if (btnJustPressed(2)) { currentState = STATE_VELHA;   velhaFullReset(); }
      if (btnJustPressed(3)) { currentState = STATE_QUIZ;    quizInit();       }
      if (btnJustPressed(4)) { currentState = STATE_MEMORIA; memInit();        }
      break;

    // ── PONG ────────────────────────────────────────────────────────────────
    case STATE_PONG:
      pongLoop(now);
      if (pongIsDone()) {
        if (pongPlayerWon()) { enterMotorSelect(); }
        else { currentState = STATE_MENU; drawMenu(); }
      }
      break;

    // ── VELHA ───────────────────────────────────────────────────────────────
    case STATE_VELHA:
      velhaLoop(now);
      if (velhaIsDone()) {
        if (velhaPlayerWon()) { enterMotorSelect(); }
        else { currentState = STATE_MENU; drawMenu(); }
      }
      break;

    // ── QUIZ ────────────────────────────────────────────────────────────────
    case STATE_QUIZ:
      quizLoop(now);
      if (quizIsDone()) {
        if (quizPlayerWon()) { enterMotorSelect(); }
        else { currentState = STATE_MENU; drawMenu(); }
      }
      break;

    // ── MEMÓRIA ─────────────────────────────────────────────────────────────
    case STATE_MEMORIA:
      memLoop(now);
      if (memIsDone()) {
        if (memPlayerWon()) { enterMotorSelect(); }
        else { currentState = STATE_MENU; drawMenu(); }
      }
      break;

    // ── SELEÇÃO DE MOTOR ────────────────────────────────────────────────────
    case STATE_MOTOR_SELECT:
      if (touchJustPressed() && (millis() - motorSelectEnterTime >= MOTOR_SELECT_GUARD_MS)) {
        char choice = motorSelectCheck(touchX(), touchY());
        if (choice == 'A' || choice == 'B') {
          Serial1.write(choice);   // envia 'A' ou 'B' para o Uno
          Serial1.flush();
          currentState = STATE_MENU;
          drawMenu();
        }
      }
      break;
  }
}
