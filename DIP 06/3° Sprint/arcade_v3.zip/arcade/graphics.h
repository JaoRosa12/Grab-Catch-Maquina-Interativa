#pragma once
/*
 * graphics.h — Primitivas visuais compartilhadas
 * Todas as funções de desenho genéricas ficam aqui.
 */

#include <MCUFRIEND_kbv.h>
#include <avr/pgmspace.h>

extern MCUFRIEND_kbv tft;

// ─────────────────────────────────────────────────────────────────────────────
// DIMENSÕES
// ─────────────────────────────────────────────────────────────────────────────
#define SCREEN_W 320
#define SCREEN_H 240

// ─────────────────────────────────────────────────────────────────────────────
// PALETA DE CORES
// ─────────────────────────────────────────────────────────────────────────────
#define BLACK       0x0000
#define WHITE       0xFFFF
#define GRAY        0x8410
#define DARKGRAY    0x2104
#define MIDGRAY     0x4208
#define NEON_CYAN   0x07FF
#define NEON_PINK   0xF81F
#define NEON_GREEN  0x07E0
#define NEON_YELLOW 0xFFE0
#define NEON_ORANGE 0xFC60
#define NEON_PURPLE 0x881F
#define NEON_BLUE   0x051F
#define DARK_CYAN   0x0412
#define DARK_PINK   0x6003
#define DARK_GREEN  0x0320
#define DARK_BLUE   0x0009
#define COL_BG      0x0821
#define COL_GOLD    0xFEA0

#define RGB(r,g,b) ( \
  ((uint16_t)(constrain((r),0,255)>>3)<<11) | \
  ((uint16_t)(constrain((g),0,255)>>2)<<5)  | \
  ((uint16_t)(constrain((b),0,255)>>3)) \
)

// ─────────────────────────────────────────────────────────────────────────────
// CAMPO ESTRELADO — armazenado em PROGMEM para não consumir RAM
// ─────────────────────────────────────────────────────────────────────────────
#define NUM_STARS 50

extern const uint16_t STAR_X[NUM_STARS] PROGMEM;
extern const uint8_t  STAR_Y[NUM_STARS] PROGMEM;

// ─────────────────────────────────────────────────────────────────────────────
// BOTÃO VOLTAR
// ─────────────────────────────────────────────────────────────────────────────
#define BACK_X 0
#define BACK_Y 0
#define BACK_W 72
#define BACK_H 26

// ─────────────────────────────────────────────────────────────────────────────
// DECLARAÇÕES
// ─────────────────────────────────────────────────────────────────────────────
void fillGradientV(int x, int y, int w, int h, uint16_t c1, uint16_t c2);
void drawNeonRect(int x, int y, int w, int h, uint16_t col, int radius = 6);
void drawCenteredText(int bx, int by, int bw, int bh,
                      const char *txt, int sz, uint16_t col);
void drawStar4(int cx, int cy, int r, uint16_t col);
void drawDiamond(int cx, int cy, int r, uint16_t col);
void drawStarfield();
void drawBackButton(uint16_t accentCol = NEON_PINK);
bool isBackTouch(int tx, int ty);
