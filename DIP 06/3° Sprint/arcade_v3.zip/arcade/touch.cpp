/*
 * touch.cpp — Leitura, calibração e detecção de borda do touch resistivo
 *
 * touchUpdate() lê o hardware e atualiza três flags por frame:
 *   _isPressed     → dedo detectado agora (após filtragem de pressão)
 *   _justPressed   → borda de subida + debounce de TOUCH_DEBOUNCE_MS
 *   _justReleased  → borda de descida
 *
 * Isso elimina os múltiplos debounces espalhados pelos módulos.
 * Cada módulo só precisa chamar touchJustPressed() — sem lastBackTime local.
 */

#include "touch.h"
#include "graphics.h"

TouchScreen  ts     = TouchScreen(XP, YP, XM, YM, 300);
TouchCalib   g_calib = { TS_MINX_DEFAULT, TS_MAXX_DEFAULT,
                         TS_MINY_DEFAULT, TS_MAXY_DEFAULT };

// ─────────────────────────────────────────────────────────────────────────────
// ESTADO INTERNO DO INPUT
// ─────────────────────────────────────────────────────────────────────────────
static bool          _isPressed       = false;
static bool          _justPressed     = false;
static bool          _justReleased    = false;
static bool          _prevPressed     = false;
static int           _tx              = 0;
static int           _ty              = 0;
static unsigned long _lastPressedTime = 0;  // timestamp do último justPressed válido

// ─────────────────────────────────────────────────────────────────────────────
// EEPROM
// ─────────────────────────────────────────────────────────────────────────────
void touchLoadCalib() {
  uint8_t magic = EEPROM.read(EEPROM_ADDR_MAGIC);
  if (magic != EEPROM_MAGIC) return;
  EEPROM.get(EEPROM_ADDR_DATA, g_calib);
  // Sanidade mínima
  if (g_calib.minX < 0   || g_calib.maxX > 1023 ||
      g_calib.minY < 0   || g_calib.maxY > 1023 ||
      g_calib.minX >= g_calib.maxX ||
      g_calib.minY >= g_calib.maxY) {
    g_calib = { TS_MINX_DEFAULT, TS_MAXX_DEFAULT,
                TS_MINY_DEFAULT, TS_MAXY_DEFAULT };
  }
}

void touchSaveCalib(const TouchCalib &c) {
  EEPROM.write(EEPROM_ADDR_MAGIC, EEPROM_MAGIC);
  EEPROM.put(EEPROM_ADDR_DATA, c);
}

// ─────────────────────────────────────────────────────────────────────────────
// CALIBRAÇÃO INTERATIVA — 4 cantos
// ─────────────────────────────────────────────────────────────────────────────
static TSPoint waitForStableTouch() {
  TSPoint p;
  do {
    p = ts.getPoint();
    pinMode(YP, OUTPUT); pinMode(XM, OUTPUT);
    digitalWrite(YP, HIGH); digitalWrite(XM, HIGH);
    delay(10);
  } while (p.z < MINPRESSURE || p.z > MAXPRESSURE);
  delay(200);
  TSPoint p2;
  do {
    p2 = ts.getPoint();
    pinMode(YP, OUTPUT); pinMode(XM, OUTPUT);
    digitalWrite(YP, HIGH); digitalWrite(XM, HIGH);
    delay(10);
  } while (p2.z >= MINPRESSURE);
  return p;
}

static void drawCalibCross(int cx, int cy, uint16_t col) {
  tft.drawFastHLine(cx-15, cy,  30, col);
  tft.drawFastVLine(cx,  cy-15, 30, col);
  tft.drawCircle(cx, cy, 5, col);
}

void touchRunCalibration() {
  tft.fillScreen(BLACK);
  tft.setTextSize(1); tft.setTextColor(WHITE);
  tft.setCursor(60, 100); tft.print("CALIBRACAO DO TOUCH");
  tft.setCursor(50, 116); tft.print("Toque nos 4 alvos em ordem");
  delay(2000);

  struct Corner { int cx, cy; const char *label; };
  const Corner corners[4] = {
    { 10,  10, "CANTO SUPERIOR ESQUERDO" },
    { 310, 10, "CANTO SUPERIOR DIREITO"  },
    { 10, 230, "CANTO INFERIOR ESQUERDO" },
    { 310, 230,"CANTO INFERIOR DIREITO"  }
  };

  int rawX[4], rawY[4];
  for (int i = 0; i < 4; i++) {
    tft.fillScreen(BLACK);
    tft.setTextSize(1); tft.setTextColor(NEON_CYAN);
    tft.setCursor(80, 110); tft.print(corners[i].label);
    drawCalibCross(corners[i].cx, corners[i].cy, NEON_YELLOW);
    TSPoint p = waitForStableTouch();
    rawX[i] = p.x; rawY[i] = p.y;
    tft.fillCircle(corners[i].cx, corners[i].cy, 5, NEON_GREEN);
    delay(400);
  }

  TouchCalib newCalib;
  newCalib.minX = (rawX[0] + rawX[2]) / 2;
  newCalib.maxX = (rawX[1] + rawX[3]) / 2;
  newCalib.minY = (rawY[0] + rawY[1]) / 2;
  newCalib.maxY = (rawY[2] + rawY[3]) / 2;
  if (newCalib.minX > newCalib.maxX) { int t=newCalib.minX; newCalib.minX=newCalib.maxX; newCalib.maxX=t; }
  if (newCalib.minY > newCalib.maxY) { int t=newCalib.minY; newCalib.minY=newCalib.maxY; newCalib.maxY=t; }
  touchSaveCalib(newCalib);
  g_calib = newCalib;

  tft.fillScreen(BLACK);
  tft.setTextColor(NEON_GREEN); tft.setTextSize(1);
  tft.setCursor(80, 110); tft.print("Calibracao salva!");
  delay(1500);
}

// ─────────────────────────────────────────────────────────────────────────────
// LEITURA BRUTA (usada internamente e pela calibração)
// ─────────────────────────────────────────────────────────────────────────────
static bool readRaw(int &outX, int &outY) {
  TSPoint p = ts.getPoint();
  pinMode(YP, OUTPUT); pinMode(XM, OUTPUT);
  digitalWrite(YP, HIGH); digitalWrite(XM, HIGH);
  if (p.z < MINPRESSURE || p.z > MAXPRESSURE) return false;
  outX = constrain(map(p.x, g_calib.minX, g_calib.maxX, SCREEN_W, 0), 0, SCREEN_W-1);
  outY = constrain(map(p.y, g_calib.minY, g_calib.maxY, 0, SCREEN_H),  0, SCREEN_H-1);
  return true;
}

// ─────────────────────────────────────────────────────────────────────────────
// touchUpdate() — chame UMA VEZ no início de cada loop()
//
// Lógica de borda:
//   _prevPressed → estado do frame anterior
//   _isPressed   → estado do frame atual (após filtragem)
//
//   justPressed  = !prev && curr && debounce OK
//   justReleased = prev && !curr
//
// O debounce só bloqueia justPressed, não isPressed.
// Isso garante que segurar o dedo funciona continuamente (Pong),
// mas toques rápidos repetidos (BACK) só disparam uma vez por janela.
// ─────────────────────────────────────────────────────────────────────────────
void touchUpdate() {
  _prevPressed = _isPressed;
  int rx, ry;
  _isPressed = readRaw(rx, ry);
  if (_isPressed) { _tx = rx; _ty = ry; }

  // Borda de descida — sem debounce, dispara imediatamente
  _justReleased = _prevPressed && !_isPressed;

  // Borda de subida — com debounce
  unsigned long now = millis();
  bool risingEdge   = !_prevPressed && _isPressed;
  bool debounceOk   = (now - _lastPressedTime) >= TOUCH_DEBOUNCE_MS;

  if (risingEdge && debounceOk) {
    _justPressed     = true;
    _lastPressedTime = now;
  } else {
    _justPressed = false;
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// ACCESSORS
// ─────────────────────────────────────────────────────────────────────────────
bool touchIsPressed()    { return _isPressed;    }
bool touchJustPressed()  { return _justPressed;  }
bool touchJustReleased() { return _justReleased; }
int  touchX()            { return _tx;           }
int  touchY()            { return _ty;           }
