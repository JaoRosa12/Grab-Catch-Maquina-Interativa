/*
 * menu.cpp — Menu principal e ícones dos jogos
 */

#include "menu.h"

// ─────────────────────────────────────────────────────────────────────────────
// LAYOUT DOS BOTÕES DO MENU
// ─────────────────────────────────────────────────────────────────────────────
#define BTN_W  148
#define BTN_H  110
#define BTN_X0   2
#define BTN_X1 154
#define BTN_Y0   2
#define BTN_Y1 128

// ─────────────────────────────────────────────────────────────────────────────
// ÍCONES
// ─────────────────────────────────────────────────────────────────────────────
static void drawIconPong(int bx, int by) {
  int cx=bx+BTN_W/2, cy=by+BTN_H/2-8;
  tft.fillRoundRect(cx-42,cy-20,8,40,3,NEON_CYAN);
  tft.fillRoundRect(cx+34,cy-20,8,40,3,NEON_PINK);
  tft.fillCircle(cx+2,cy+2,6,DARKGRAY);
  tft.fillCircle(cx,  cy,  6,NEON_YELLOW);
  tft.fillCircle(cx-2,cy-2,2,WHITE);
  for (int yy=cy-22;yy<cy+24;yy+=7) tft.drawFastVLine(cx,yy,4,MIDGRAY);
  drawCenteredText(bx,by+BTN_H-24,BTN_W,12,"PONG vs CPU",1,NEON_CYAN);
}

static void drawIconVelha(int bx, int by) {
  int cx=bx+BTN_W/2, cy=by+BTN_H/2-10;
  int gs=15, gox=cx-gs*3/2, goy=cy-gs*3/2;
  for (int i=1;i<3;i++) {
    tft.drawFastVLine(gox+i*gs,   goy,gs*3,DARK_GREEN);
    tft.drawFastVLine(gox+i*gs+1, goy,gs*3,NEON_GREEN);
    tft.drawFastHLine(gox,goy+i*gs,  gs*3,DARK_GREEN);
    tft.drawFastHLine(gox,goy+i*gs+1,gs*3,NEON_GREEN);
  }
  int mx=gox+gs+gs/2, my=goy+gs+gs/2, r2=gs/2-2;
  tft.drawLine(mx-r2,my-r2,mx+r2,my+r2,NEON_PINK);
  tft.drawLine(mx-r2+1,my-r2,mx+r2+1,my+r2,NEON_PINK);
  tft.drawLine(mx-r2,my+r2,mx+r2,my-r2,NEON_PINK);
  tft.drawLine(mx-r2+1,my+r2,mx+r2+1,my-r2,NEON_PINK);
  tft.drawCircle(gox+gs/2,goy+gs/2,gs/2-3,NEON_CYAN);
  drawCenteredText(bx,by+BTN_H-24,BTN_W,12,"VELHA vs CPU",1,NEON_GREEN);
}

static void drawIconQuiz(int bx, int by) {
  int cx=bx+BTN_W/2, cy=by+BTN_H/2-12;
  tft.setTextSize(4); tft.setTextColor(NEON_YELLOW);
  tft.setCursor(cx-12,cy-22); tft.print("?");
  // 4 mini-botões de alternativa
  const uint16_t cols[4] = {NEON_CYAN,NEON_GREEN,NEON_ORANGE,NEON_PINK};
  const char labels[4][2] = {"A","B","C","D"};
  const int bw2=28, bh2=12, gap=4;
  int startX = bx+(BTN_W-(bw2*2+gap))/2;
  for (int i=0;i<4;i++) {
    int ox=startX+(i%2)*(bw2+gap);
    int oy=cy+16+(i/2)*(bh2+gap);
    tft.fillRoundRect(ox,oy,bw2,bh2,2,cols[i]);
    tft.setTextSize(1); tft.setTextColor(BLACK);
    tft.setCursor(ox+3,oy+2); tft.print(labels[i]);
  }
  drawCenteredText(bx,by+BTN_H-24,BTN_W,12,"QUIZ",1,NEON_YELLOW);
}

static void drawIconMemoria(int bx, int by) {
  int cx=bx+BTN_W/2, cy=by+BTN_H/2-10;
  const int cw=22, ch=18, gap=4;
  int ox=cx-(cw*3+gap*2)/2;
  int oy=cy-(ch*3+gap*2)/2;
  const uint16_t cardCols[9] = {
    NEON_CYAN, DARKGRAY, NEON_PINK,
    DARKGRAY, NEON_PURPLE, DARKGRAY,
    NEON_ORANGE, DARKGRAY, NEON_CYAN
  };
  for (int r=0;r<3;r++) {
    for (int c=0;c<3;c++) {
      int x=ox+c*(cw+gap), y=oy+r*(ch+gap);
      tft.fillRoundRect(x,y,cw,ch,2,cardCols[r*3+c]);
      if (cardCols[r*3+c]!=DARKGRAY) {
        tft.drawRoundRect(x,y,cw,ch,2,WHITE);
      } else {
        tft.drawLine(x+cw/2,y+2,x+cw-2,y+ch/2,MIDGRAY);
        tft.drawLine(x+cw-2,y+ch/2,x+cw/2,y+ch-2,MIDGRAY);
        tft.drawLine(x+cw/2,y+ch-2,x+2,y+ch/2,MIDGRAY);
        tft.drawLine(x+2,y+ch/2,x+cw/2,y+2,MIDGRAY);
      }
    }
  }
  drawCenteredText(bx,by+BTN_H-24,BTN_W,12,"MEMORIA",1,NEON_PURPLE);
}

// ─────────────────────────────────────────────────────────────────────────────
// BOTÃO DE MENU COMPLETO (fundo + borda + ícone)
// ─────────────────────────────────────────────────────────────────────────────
static void drawMenuButton(int bx, int by, int slot) {
  uint16_t c1, c2, neon;
  switch (slot) {
    case 1: c1=RGB(0,10,60);  c2=RGB(0,4,20);  neon=NEON_CYAN;   break;
    case 2: c1=RGB(0,30,10);  c2=RGB(0,10,4);  neon=NEON_GREEN;  break;
    case 3: c1=RGB(40,30,0);  c2=RGB(15,10,0); neon=NEON_YELLOW; break;
    case 4: c1=RGB(20,0,30);  c2=RGB(8,0,12);  neon=NEON_PURPLE; break;
    default:c1=DARKGRAY;      c2=BLACK;         neon=GRAY;        break;
  }
  fillGradientV(bx,by,BTN_W,BTN_H,c1,c2);
  drawNeonRect(bx,by,BTN_W,BTN_H,neon,8);
  if      (slot==1) drawIconPong(bx,by);
  else if (slot==2) drawIconVelha(bx,by);
  else if (slot==3) drawIconQuiz(bx,by);
  else if (slot==4) drawIconMemoria(bx,by);
}

// ─────────────────────────────────────────────────────────────────────────────
// INTERFACE PÚBLICA
// ─────────────────────────────────────────────────────────────────────────────
void drawMenu() {
  fillGradientV(0,0,SCREEN_W,SCREEN_H,COL_BG,BLACK);
  drawStarfield();
  for (int y=0;y<SCREEN_H;y+=4) tft.drawFastHLine(0,y,SCREEN_W,RGB(0,2,4));
  drawStar4(6,   6,   5,COL_GOLD);
  drawStar4(314, 6,   5,COL_GOLD);
  drawStar4(6,   234, 5,COL_GOLD);
  drawStar4(314, 234, 5,COL_GOLD);
  drawDiamond(160,120,7,RGB(0,12,28));
  tft.drawFastHLine(2,120,SCREEN_W-4,RGB(0,10,24));
  tft.drawFastVLine(152,2,SCREEN_H-4,RGB(0,10,24));
  drawMenuButton(BTN_X0,BTN_Y0,1);
  drawMenuButton(BTN_X1,BTN_Y0,2);
  drawMenuButton(BTN_X0,BTN_Y1,3);
  drawMenuButton(BTN_X1,BTN_Y1,4);
  tft.fillRect(133,112,54,16,COL_BG);
  tft.setTextSize(1); tft.setTextColor(COL_GOLD);
  tft.setCursor(137,116); tft.print("ARCADE");
}

int checkMenuTouch(int tx, int ty) {
  if (tx>=BTN_X0 && tx<BTN_X0+BTN_W) {
    if (ty>=BTN_Y0 && ty<BTN_Y0+BTN_H) return 1;
    if (ty>=BTN_Y1 && ty<BTN_Y1+BTN_H) return 3;
  }
  if (tx>=BTN_X1 && tx<BTN_X1+BTN_W) {
    if (ty>=BTN_Y0 && ty<BTN_Y0+BTN_H) return 2;
    if (ty>=BTN_Y1 && ty<BTN_Y1+BTN_H) return 4;
  }
  return 0;
}
