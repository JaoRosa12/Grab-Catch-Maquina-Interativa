/*
 * memoria.cpp — Jogo da Memória 4×4 (8 pares de símbolos)
 */

#include "memoria.h"
#include "touch.h"
#include <math.h>

// ─────────────────────────────────────────────────────────────────────────────
// CONSTANTES
// ─────────────────────────────────────────────────────────────────────────────
#define MEM_COLS     4
#define MEM_ROWS     4
#define MEM_CARDS    (MEM_COLS * MEM_ROWS)
#define MEM_PAIRS    (MEM_CARDS / 2)

#define MEM_CELL_W   68
#define MEM_CELL_H   50
#define MEM_GAP       3
#define MEM_OX       ((SCREEN_W - (MEM_CELL_W*MEM_COLS + MEM_GAP*(MEM_COLS-1)))/2)
#define MEM_OY        34

#define MEM_MISS_DELAY   700
#define MEM_MATCH_DELAY  400
#define VICTORY_DELAY_MS 3000

// ─────────────────────────────────────────────────────────────────────────────
// ESTADO INTERNO
// ─────────────────────────────────────────────────────────────────────────────
enum MemState { MEM_IDLE, MEM_FIRST, MEM_SECOND, MEM_MATCH_ANIM, MEM_MISS_ANIM };

struct MemCard {
  uint8_t symbol;
  bool    revealed;
  bool    matched;
};

static MemCard   memCards[MEM_CARDS];
static MemState  memState   = MEM_IDLE;
static int       memFirst   = -1;
static int       memSecond  = -1;
static int       memMatched = 0;
static int       memTries   = 0;
static bool      memDone    = false;
static bool      memPlayerWonFlag = false;

static bool          memVictoryPending   = false;
static unsigned long memVictoryStartTime = 0;
static unsigned long memAnimTimer        = 0;

// Cores dos 8 símbolos
static const uint16_t MEM_SYM_COLORS[8] = {
  NEON_PINK, NEON_YELLOW, NEON_CYAN, NEON_GREEN,
  NEON_ORANGE, NEON_PURPLE, WHITE, RGB(0,25,40)
};
static const uint16_t MEM_SYM_DARK[8] = {
  DARK_PINK, RGB(20,20,0), DARK_CYAN, DARK_GREEN,
  RGB(20,8,0), RGB(8,0,12), MIDGRAY, RGB(0,8,15)
};

// ─────────────────────────────────────────────────────────────────────────────
// DESENHO DE SÍMBOLOS
// ─────────────────────────────────────────────────────────────────────────────
static void memDrawSymbol(int cx, int cy, int sym) {
  uint16_t c = MEM_SYM_COLORS[sym];
  uint16_t d = MEM_SYM_DARK[sym];
  int r = 13;
  switch (sym) {
    case 0: // Coração
      tft.fillCircle(cx-7,cy-5,7,c);
      tft.fillCircle(cx+7,cy-5,7,c);
      tft.fillTriangle(cx-14,cy-2,cx+14,cy-2,cx,cy+14,c);
      tft.drawPixel(cx,cy+2,WHITE);
      break;
    case 1: // Estrela 5pts
      for (int a=0;a<5;a++) {
        float ang1=(a*72-90)*3.14159f/180.0f;
        float ang2=(a*72+36-90)*3.14159f/180.0f;
        int x1=cx+(int)(r*cos(ang1)),    y1=cy+(int)(r*sin(ang1));
        int x2=cx+(int)(6*cos(ang2)),    y2=cy+(int)(6*sin(ang2));
        int x3=cx+(int)(r*cos(ang1+72*3.14159f/180.0f));
        int y3=cy+(int)(r*sin(ang1+72*3.14159f/180.0f));
        tft.fillTriangle(x1,y1,x2,y2,x3,y3,c);
      }
      tft.fillCircle(cx,cy,5,c);
      break;
    case 2: // Círculo
      tft.fillCircle(cx,cy,r,d);
      tft.fillCircle(cx,cy,r-2,c);
      tft.fillCircle(cx-4,cy-4,3,WHITE);
      break;
    case 3: // Quadrado
      tft.fillRoundRect(cx-r,cy-r,r*2,r*2,3,d);
      tft.fillRoundRect(cx-r+2,cy-r+2,r*2-4,r*2-4,3,c);
      tft.drawPixel(cx-r+4,cy-r+4,WHITE);
      break;
    case 4: // Triângulo
      tft.fillTriangle(cx,cy-r,cx+r,cy+r-2,cx-r,cy+r-2,d);
      tft.fillTriangle(cx,cy-r+2,cx+r-3,cy+r-3,cx-r+3,cy+r-3,c);
      break;
    case 5: // Diamante
      tft.fillTriangle(cx-r,cy,cx,cy-r,cx+r,cy,d);
      tft.fillTriangle(cx-r,cy,cx,cy+r,cx+r,cy,d);
      tft.fillTriangle(cx-r+3,cy,cx,cy-r+3,cx+r-3,cy,c);
      tft.fillTriangle(cx-r+3,cy,cx,cy+r-3,cx+r-3,cy,c);
      break;
    case 6: // Cruz
      tft.fillRect(cx-r,cy-5,r*2,10,c);
      tft.fillRect(cx-5,cy-r,10,r*2,c);
      tft.fillRect(cx-3,cy-3,6,6,WHITE);
      break;
    case 7: // Lua crescente
      tft.fillCircle(cx,cy,r,c);
      tft.fillCircle(cx+7,cy-4,r-2,RGB(0,6,16));
      tft.drawCircle(cx,cy,r,d);
      break;
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// EMBARALHAMENTO
// ─────────────────────────────────────────────────────────────────────────────
static void memShuffle() {
  for (int i=0;i<MEM_CARDS;i++) {
    memCards[i].symbol   = i % MEM_PAIRS;
    memCards[i].revealed = false;
    memCards[i].matched  = false;
  }
  uint16_t seed = (uint16_t)(millis()&0xFFFF) ^ 0xA5A5;
  for (int i=MEM_CARDS-1;i>0;i--) {
    seed = seed*6364+1;
    int j = seed%(i+1);
    MemCard tmp=memCards[i]; memCards[i]=memCards[j]; memCards[j]=tmp;
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// POSIÇÃO DAS CARTAS
// ─────────────────────────────────────────────────────────────────────────────
static int memCardX(int col) { return MEM_OX + col*(MEM_CELL_W+MEM_GAP); }
static int memCardY(int row) { return MEM_OY + row*(MEM_CELL_H+MEM_GAP); }

// ─────────────────────────────────────────────────────────────────────────────
// DESENHO DE CARTA INDIVIDUAL (sem fillScreen — dirty rect)
// ─────────────────────────────────────────────────────────────────────────────
static void memDrawCard(int idx) {
  int col = idx % MEM_COLS;
  int row = idx / MEM_COLS;
  int x = memCardX(col), y = memCardY(row);
  MemCard &c = memCards[idx];

  if (!c.revealed && !c.matched) {
    // Carta oculta
    tft.fillRoundRect(x,y,MEM_CELL_W,MEM_CELL_H,4,RGB(0,4,14));
    drawNeonRect(x,y,MEM_CELL_W,MEM_CELL_H,NEON_BLUE,4);
    int cx2=x+MEM_CELL_W/2, cy2=y+MEM_CELL_H/2, rr=8;
    tft.drawLine(cx2,cy2-rr,cx2+rr,cy2,MIDGRAY);
    tft.drawLine(cx2+rr,cy2,cx2,cy2+rr,MIDGRAY);
    tft.drawLine(cx2,cy2+rr,cx2-rr,cy2,MIDGRAY);
    tft.drawLine(cx2-rr,cy2,cx2,cy2-rr,MIDGRAY);
  } else if (c.matched) {
    // Par encontrado: fundo esverdeado
    tft.fillRoundRect(x,y,MEM_CELL_W,MEM_CELL_H,4,RGB(0,12,4));
    drawNeonRect(x,y,MEM_CELL_W,MEM_CELL_H,NEON_GREEN,4);
    memDrawSymbol(x+MEM_CELL_W/2, y+MEM_CELL_H/2, c.symbol);
  } else {
    // Revelada (não confirmada)
    tft.fillRoundRect(x,y,MEM_CELL_W,MEM_CELL_H,4,RGB(2,8,22));
    drawNeonRect(x,y,MEM_CELL_W,MEM_CELL_H,MEM_SYM_COLORS[c.symbol],4);
    memDrawSymbol(x+MEM_CELL_W/2, y+MEM_CELL_H/2, c.symbol);
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// HUD
// ─────────────────────────────────────────────────────────────────────────────
static void memDrawHUD() {
  fillGradientV(0,0,SCREEN_W,MEM_OY-1,RGB(15,0,25),RGB(5,0,10));
  tft.drawFastHLine(0,MEM_OY-1,SCREEN_W,NEON_PURPLE);
  tft.setTextSize(1); tft.setTextColor(NEON_PURPLE);
  tft.setCursor(BACK_W+8,4);  tft.print("MEMORIA");
  tft.setTextColor(NEON_GREEN);
  tft.setCursor(BACK_W+8,15); tft.print("Pares: ");
  tft.print(memMatched); tft.print("/"); tft.print(MEM_PAIRS);
  tft.setTextColor(MIDGRAY);
  tft.setCursor(220,4);  tft.print("Tents:");
  tft.setCursor(220,15); tft.print(memTries);
  drawBackButton(NEON_PURPLE);
}

static void memDrawAll() {
  tft.fillScreen(BLACK);
  memDrawHUD();
  for (int i=0;i<MEM_CARDS;i++) memDrawCard(i);
}

// ─────────────────────────────────────────────────────────────────────────────
// VITÓRIA
// ─────────────────────────────────────────────────────────────────────────────
static void memShowVictory() {
  int bw=SCREEN_W-30, bh=80, bx=15, by=SCREEN_H/2-bh/2;
  fillGradientV(bx,by,bw,bh,RGB(0,15,5),RGB(0,6,2));
  drawNeonRect(bx,by,bw,bh,NEON_GREEN,8);
  drawStar4(bx+10,by+10,4,COL_GOLD); drawStar4(bx+bw-10,by+10,4,COL_GOLD);
  drawStar4(bx+10,by+bh-10,4,COL_GOLD); drawStar4(bx+bw-10,by+bh-10,4,COL_GOLD);
  drawCenteredText(bx,by+4,bw,bh/2-4,"PARABENS!",2,NEON_GREEN);
  char statBuf[28];
  snprintf(statBuf,sizeof(statBuf),"Tentativas: %d",memTries);
  drawCenteredText(bx,by+bh/2+2,bw,bh/2-8,statBuf,1,GRAY);
  drawCenteredText(bx,by+bh-14,bw,12,"Voltando ao menu...",1,MIDGRAY);
}

// ─────────────────────────────────────────────────────────────────────────────
// HIT TEST
// ─────────────────────────────────────────────────────────────────────────────
static int memHitTest(int tx, int ty) {
  for (int r=0;r<MEM_ROWS;r++) {
    for (int c=0;c<MEM_COLS;c++) {
      int x=memCardX(c), y=memCardY(r);
      if (tx>=x && tx<x+MEM_CELL_W && ty>=y && ty<y+MEM_CELL_H) {
        int idx = r*MEM_COLS+c;
        if (!memCards[idx].matched && !memCards[idx].revealed) return idx;
      }
    }
  }
  return -1;
}

// ─────────────────────────────────────────────────────────────────────────────
// INTERFACE PÚBLICA
// ─────────────────────────────────────────────────────────────────────────────
void memInit() {
  memShuffle();
  memState=MEM_IDLE; memFirst=-1; memSecond=-1;
  memMatched=0; memTries=0;
  memVictoryPending=false; memDone=false; memPlayerWonFlag=false;
  memDrawAll();
}

void memLoop(unsigned long now) {
  // Animações não-bloqueantes — processam independente de toque
  if (memState == MEM_MATCH_ANIM) {
    if (now - memAnimTimer >= MEM_MATCH_DELAY) {
      memDrawCard(memFirst); memDrawCard(memSecond);
      memDrawHUD();
      memFirst = -1; memSecond = -1; memState = MEM_IDLE;
      if (memMatched >= MEM_PAIRS) {
        memShowVictory();
        memVictoryPending = true; memVictoryStartTime = millis(); memPlayerWonFlag = true;

      }
    }
    return;
  }

  if (memState == MEM_MISS_ANIM) {
    if (now - memAnimTimer >= MEM_MISS_DELAY) {
      memCards[memFirst].revealed  = false;
      memCards[memSecond].revealed = false;
      memDrawCard(memFirst); memDrawCard(memSecond);
      memFirst = -1; memSecond = -1; memState = MEM_IDLE;
    }
    return;
  }

  if (memVictoryPending) {
    if (touchJustPressed() && isBackTouch(touchX(), touchY())) {
      memDone = true; return;
    }
    if (now - memVictoryStartTime >= VICTORY_DELAY_MS) memDone = true;
    return;
  }

  if (!touchJustPressed()) return;
  int tx = touchX(), ty = touchY();

  if (isBackTouch(tx, ty)) { memDone = true; return; }

  int idx = memHitTest(tx, ty);
  if (idx < 0) return;

  memCards[idx].revealed = true;
  memDrawCard(idx);

  if (memState == MEM_IDLE) {
    memFirst = idx; memState = MEM_FIRST;
  } else if (memState == MEM_FIRST && idx != memFirst) {
    memSecond = idx; memTries++;
    memDrawHUD();
    if (memCards[memFirst].symbol == memCards[memSecond].symbol) {
      memCards[memFirst].matched  = true;
      memCards[memSecond].matched = true;
      memMatched++;
      memState = MEM_MATCH_ANIM; memAnimTimer = millis();
    } else {
      memState = MEM_MISS_ANIM; memAnimTimer = millis();
    }
  }
}

bool memIsDone()    { return memDone; }
bool memPlayerWon() { return memDone && memPlayerWonFlag; }
