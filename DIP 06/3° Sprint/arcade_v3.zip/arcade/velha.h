#pragma once
/*
 * velha.h — Jogo da Velha vs CPU (Minimax)
 */

#include <Arduino.h>
#include "graphics.h"

void velhaInit();
void velhaFullReset();
void velhaLoop(unsigned long now);
bool velhaIsDone();
bool velhaPlayerWon();  // true somente se o jogador venceu a série
