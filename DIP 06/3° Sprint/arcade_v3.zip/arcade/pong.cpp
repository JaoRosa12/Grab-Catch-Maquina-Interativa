/*
 * pong.cpp — Jogo Pong vs CPU
 *
 * Física em ponto fixo: posições e velocidades são inteiros ×100.
 * Ex: posX=16000 representa x=160.00 px.
 * Isso elimina float do loop principal mantendo precisão suficiente.
 *
 * IA aprimorada: CPU aplica erro aleatório no target e só age
 * quando a bola está vindo em sua direção.
 */

#include "pong.h"
#include "touch.h"
#include "buttons.h"
// ─────────────────────────────────────────────────────────────────────────────
struct Paddle { int x, y, score; };

struct Ball {
  long x, y;    // ponto fixo ×100
  long vx, vy;  // ponto fixo ×100
};

static Paddle pLeft, pRight;
static Ball   ball;

static int prevBallX = -99, prevBallY = -99;

static unsigned long lastPongUpdate    = 0;
static unsigned long victoryStartTime  = 0;
static bool          victoryPending    = false;
static int           victoryWinner     = 0;
static unsigned long pongResetTimer    = 0;
static bool          pongResetPending  = false;
static bool          pongDone          = false;

// Semente para pseudo-random leve (sem usar rand() que é pesado)
static uint16_t pongRandSeed = 0xBEEF;

static int pongRandSmall(int maxVal) {
  pongRandSeed = pongRandSeed * 6364 + 1442;
  return (int)(pongRandSeed % (uint16_t)(maxVal + 1));
}

// ─────────────────────────────────────────────────────────────────────────────
// HELPERS DE CONVERSÃO ponto fixo ↔ pixel
// ─────────────────────────────────────────────────────────────────────────────
static inline int toPixel(long v)  { return (int)(v / 100); }
static inline long toFixed(int v)  { return (long)v * 100; }

// ─────────────────────────────────────────────────────────────────────────────
// LINHA CENTRAL PONTILHADA
// ─────────────────────────────────────────────────────────────────────────────
static void restoreCenterLine(int yTop, int yBot) {
  int cx = SCREEN_W/2;
  for (int y = yTop; y < yBot; y+=8)
    tft.drawFastVLine(cx, y, 4, MIDGRAY);
}

// ─────────────────────────────────────────────────────────────────────────────
// DESENHO DE RAQUETE
// ─────────────────────────────────────────────────────────────────────────────
static void drawPaddle(Paddle &p, bool erase = false) {
  if (erase) {
    tft.fillRect(p.x-2, p.y-2, PADDLE_W+6, PADDLE_H+4, ARENA_BG);
    int cx = SCREEN_W/2;
    if (p.x-2 <= cx && p.x-2+PADDLE_W+6 >= cx)
      restoreCenterLine(PLAY_Y1, SCREEN_H);
    return;
  }
  uint16_t col = (&p == &pLeft) ? P1_COLOR : P2_COLOR;
  tft.fillRoundRect(p.x+2, p.y+2, PADDLE_W, PADDLE_H, 3, DARKGRAY);
  tft.fillRoundRect(p.x,   p.y,   PADDLE_W, PADDLE_H, 3, col);
  uint16_t bright =
    (((col>>11)&0x1F)<28 ? (((col>>11)&0x1F)+4) : 31) << 11 |
    ((((col>>5)&0x3F)<56 ? (((col>>5)&0x3F)+8)  : 63) << 5) |
    ((col&0x1F)<28 ? ((col&0x1F)+4) : 31);
  tft.drawFastVLine(p.x+2, p.y+3, PADDLE_H-6, bright);
}

// ─────────────────────────────────────────────────────────────────────────────
// BOLA — desenha e apaga rastro anterior (dirty rectangles)
// ─────────────────────────────────────────────────────────────────────────────
static void ballDrawAndEraseTail(int newBx, int newBy, int oldBx, int oldBy) {
  tft.fillCircle(newBx+2, newBy+2, BALL_R, DARKGRAY);
  tft.fillCircle(newBx,   newBy,   BALL_R, BALL_COL);
  tft.fillCircle(newBx-2, newBy-2, BALL_R/2, WHITE);
  if (oldBx == -99) return;

  int ox = oldBx-BALL_R-1, oy = oldBy-BALL_R-1;
  int ow = BALL_R*2+5,     oh = BALL_R*2+5;
  int nx = newBx-BALL_R-1, ny = newBy-BALL_R-1;
  int nw = BALL_R*2+5,     nh = BALL_R*2+5;
  int ix1 = max(ox,nx), iy1 = max(oy,ny);
  int ix2 = min(ox+ow,nx+nw), iy2 = min(oy+oh,ny+nh);
  bool hasOverlap = (ix1 < ix2 && iy1 < iy2);

  auto eraseRect = [](int rx, int ry, int rw, int rh) {
    if (rx < 2)             { rw += rx-2; rx = 2; }
    if (ry < PLAY_Y1+1)     { rh += ry-(PLAY_Y1+1); ry = PLAY_Y1+1; }
    if (rx+rw > SCREEN_W-2) { rw = SCREEN_W-2-rx; }
    if (ry+rh > SCREEN_H-1) { rh = SCREEN_H-1-ry; }
    if (rw > 0 && rh > 0) {
      tft.fillRect(rx, ry, rw, rh, ARENA_BG);
      int cx = SCREEN_W/2;
      if (rx <= cx && rx+rw >= cx) restoreCenterLine(PLAY_Y1, SCREEN_H);
    }
  };

  if (!hasOverlap) {
    eraseRect(ox, oy, ow, oh);
  } else {
    if (ox < ix1)       eraseRect(ox, oy, ix1-ox, oh);
    if (ox+ow > ix2)    eraseRect(ix2, oy, ox+ow-ix2, oh);
    if (oy < iy1)       eraseRect(ox, oy, ow, iy1-oy);
    if (oy+oh > iy2)    eraseRect(ox, iy2, ow, oy+oh-iy2);
    int cx = SCREEN_W/2;
    if (ox <= cx && ox+ow >= cx) restoreCenterLine(PLAY_Y1, SCREEN_H);
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// FLASH DE PONTO
// ─────────────────────────────────────────────────────────────────────────────
static void pongPointFlash(int winner) {
  uint16_t col = (winner==1) ? P1_COLOR : P2_COLOR;
  for (int i = 0; i < 3; i++) {
    tft.drawRect(2, PLAY_Y1+2, SCREEN_W-4, PLAY_H-4, col);
    delay(60);
    tft.drawRect(2, PLAY_Y1+2, SCREEN_W-4, PLAY_H-4, ARENA_BG);
    delay(40);
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// RESET DA BOLA
// ─────────────────────────────────────────────────────────────────────────────
static void pongResetBall(int direction) {
  ball.x  = toFixed(SCREEN_W / 2);
  ball.y  = toFixed(PLAY_Y1 + PLAY_H / 2);
  ball.vx = (long)direction * BALL_VX_INIT;
  ball.vy = BALL_VY_INIT;
  prevBallX = -99; prevBallY = -99;
}

// ─────────────────────────────────────────────────────────────────────────────
// HUD
// ─────────────────────────────────────────────────────────────────────────────
static void pongDrawHUD() {
  fillGradientV(0, 0, SCREEN_W, HUD_Y, RGB(5,8,25), RGB(2,4,12));
  tft.drawFastHLine(0, HUD_Y, SCREEN_W, NEON_BLUE);
  tft.setTextSize(1); tft.setTextColor(P1_COLOR);
  tft.setCursor(BACK_W+6, 3);  tft.print("YOU");
  tft.setTextSize(2); tft.setCursor(BACK_W+6, 12); tft.print(pLeft.score);
  tft.setTextSize(1); tft.setTextColor(COL_GOLD);
  tft.setCursor(148, 10); tft.print("VS");
  tft.setTextSize(1); tft.setTextColor(P2_COLOR);
  tft.setCursor(176, 3);  tft.print("CPU");
  tft.setTextSize(2); tft.setCursor(176, 12); tft.print(pRight.score);
  tft.setTextSize(1); tft.setTextColor(MIDGRAY);
  tft.setCursor(248, 10); tft.print("/ "); tft.print(WIN_SCORE);
  drawBackButton(NEON_PINK);
}

// ─────────────────────────────────────────────────────────────────────────────
// ARENA
// ─────────────────────────────────────────────────────────────────────────────
static void pongDrawArena() {
  tft.fillRect(0, PLAY_Y1, SCREEN_W, PLAY_H, ARENA_BG);
  tft.drawFastHLine(0, PLAY_Y1,    SCREEN_W, NEON_BLUE);
  tft.drawFastHLine(0, SCREEN_H-1, SCREEN_W, NEON_BLUE);
  tft.drawFastVLine(0,          PLAY_Y1, PLAY_H, P1_COLOR);
  tft.drawFastVLine(1,          PLAY_Y1, PLAY_H, DARK_CYAN);
  tft.drawFastVLine(SCREEN_W-1, PLAY_Y1, PLAY_H, P2_COLOR);
  tft.drawFastVLine(SCREEN_W-2, PLAY_Y1, PLAY_H, DARK_PINK);
  restoreCenterLine(PLAY_Y1, SCREEN_H);
}

// ─────────────────────────────────────────────────────────────────────────────
// MOVER RAQUETE (jogador ou CPU)
// ─────────────────────────────────────────────────────────────────────────────
static void pongMovePaddle(Paddle &p, int newY) {
  newY = constrain(newY, PLAY_Y1+1, SCREEN_H - PADDLE_H - 1);
  int delta = newY - p.y;
  if (abs(delta) < 2) return;
  int oldY = p.y;
  p.y = newY;
  const int SHADOW_MARGIN = 3;
  int trailRectX = p.x - 2;
  int trailRectW = PADDLE_W + SHADOW_MARGIN + 2;
  int cx = SCREEN_W/2;
  if (delta < 0) {
    int trailTop = newY + PADDLE_H;
    int trailH   = (oldY + PADDLE_H + SHADOW_MARGIN) - trailTop;
    if (trailH > 0) {
      tft.fillRect(trailRectX, trailTop, trailRectW, trailH, ARENA_BG);
      if (trailRectX <= cx && trailRectX+trailRectW >= cx)
        restoreCenterLine(PLAY_Y1, SCREEN_H);
    }
  } else {
    int trailTop = oldY - 1;
    int trailH   = (newY - 1) - trailTop + 1;
    if (trailH > 0) {
      tft.fillRect(trailRectX, trailTop, trailRectW, trailH, ARENA_BG);
      if (trailRectX <= cx && trailRectX+trailRectW >= cx)
        restoreCenterLine(PLAY_Y1, SCREEN_H);
    }
  }
  drawPaddle(p);
}

// ─────────────────────────────────────────────────────────────────────────────
// IA DA CPU — aprimorada
//
// Melhorias em relação à v10:
// 1. Só se move quando ball.vx > 0 (bola vindo para ela) — antes checava sempre
// 2. Aplica erro aleatório no target (±CPU_ERROR_MAX px), tornando-a falível
// 3. Usa step proporcional à distância, limitado por CPU_SPEED
// ─────────────────────────────────────────────────────────────────────────────
static void pongCpuMove() {
  int ballPx = toPixel(ball.x);
  int ballPy = toPixel(ball.y);

  // CPU só reage quando a bola está vindo em sua direção
  if (ball.vx <= 0) return;

  // Target com erro aleatório: CPU não é perfeita
  int errorOffset = pongRandSmall(CPU_ERROR_MAX * 2) - CPU_ERROR_MAX;
  int target = ballPy + errorOffset;

  int paddleCenterY = pRight.y + PADDLE_H/2;
  int diff = target - paddleCenterY;

  int step = 0;
  if (diff >  4) step =  min(diff/2 + 1, CPU_SPEED);
  if (diff < -4) step = -min(-diff/2 + 1, CPU_SPEED);

  if (step != 0) pongMovePaddle(pRight, pRight.y + step);
}

// ─────────────────────────────────────────────────────────────────────────────
// TELA DE VITÓRIA
// ─────────────────────────────────────────────────────────────────────────────
static void showVictory(int winner) {
  int bw = SCREEN_W-30, bh = 80;
  int bx = 15, by = SCREEN_H/2 - bh/2;
  fillGradientV(bx, by, bw, bh, RGB(0,0,40), RGB(10,0,30));
  uint16_t col = (winner==1) ? P1_COLOR : P2_COLOR;
  drawNeonRect(bx, by, bw, bh, col, 8);
  drawStar4(bx+10,    by+10,    4, COL_GOLD);
  drawStar4(bx+bw-10, by+10,    4, COL_GOLD);
  drawStar4(bx+10,    by+bh-10, 4, COL_GOLD);
  drawStar4(bx+bw-10, by+bh-10, 4, COL_GOLD);
  const char *line1 = (winner==1) ? "VOCE VENCEU!" : " CPU VENCEU!";
  const char *line2 = (winner==1) ? " PARABENS! "  : "Tente novamente";
  drawCenteredText(bx, by+4,      bw, bh/2-4, line1, 2, col);
  drawCenteredText(bx, by+bh/2+2, bw, bh/2-8, line2, 1, GRAY);
  drawCenteredText(bx, by+bh-14,  bw, 12, "Voltando ao menu...", 1, MIDGRAY);
}

// ─────────────────────────────────────────────────────────────────────────────
// PONG INIT
// ─────────────────────────────────────────────────────────────────────────────
void pongInit() {
  tft.fillScreen(BLACK);
  pLeft.x    = 6;
  pLeft.y    = PLAY_Y1 + (PLAY_H - PADDLE_H)/2;
  pLeft.score = 0;
  pRight.x   = SCREEN_W - 6 - PADDLE_W;
  pRight.y   = pLeft.y;
  pRight.score = 0;
  victoryPending   = false;
  pongResetPending = false;
  pongDone         = false;
  pongRandSeed     = (uint16_t)(millis() & 0xFFFF) ^ 0x1234;
  pongResetBall(1);
  pongDrawArena();
  pongDrawHUD();
  drawPaddle(pLeft);
  drawPaddle(pRight);
  int bx = toPixel(ball.x), by = toPixel(ball.y);
  tft.fillCircle(bx+2, by+2, BALL_R, DARKGRAY);
  tft.fillCircle(bx,   by,   BALL_R, BALL_COL);
  tft.fillCircle(bx-2, by-2, BALL_R/2, WHITE);
}

// ─────────────────────────────────────────────────────────────────────────────
// PONG UPDATE — física em ponto fixo
// ─────────────────────────────────────────────────────────────────────────────
static void pongUpdate() {
  if (pongResetPending) return;

  ball.x += ball.vx; ball.y += ball.vy;

  // Clamp velocidade
  ball.vx = constrain(ball.vx, -BALL_VX_MAX, BALL_VX_MAX);
  ball.vy = constrain(ball.vy, -BALL_VY_MAX, BALL_VY_MAX);

  int newBx = toPixel(ball.x), newBy = toPixel(ball.y);

  // Parede superior
  if (newBy - BALL_R <= PLAY_Y1) {
    ball.y = toFixed(PLAY_Y1 + BALL_R + 1); newBy = toPixel(ball.y);
    if (ball.vy < 0) ball.vy = -ball.vy;
    tft.drawFastHLine(0, PLAY_Y1, SCREEN_W, WHITE);
    tft.drawFastHLine(0, PLAY_Y1, SCREEN_W, NEON_BLUE);
    pongCpuMove();
    ballDrawAndEraseTail(newBx, newBy, prevBallX, prevBallY);
    prevBallX = newBx; prevBallY = newBy;
    return;
  }

  // Parede inferior
  if (newBy + BALL_R >= SCREEN_H-1) {
    ball.y = toFixed(SCREEN_H - 1 - BALL_R); newBy = toPixel(ball.y);
    if (ball.vy > 0) ball.vy = -ball.vy;
    tft.drawFastHLine(0, SCREEN_H-1, SCREEN_W, WHITE);
    tft.drawFastHLine(0, SCREEN_H-1, SCREEN_W, NEON_BLUE);
    pongCpuMove();
    ballDrawAndEraseTail(newBx, newBy, prevBallX, prevBallY);
    prevBallX = newBx; prevBallY = newBy;
    return;
  }

  // Colisão raquete esquerda (jogador)
  if (ball.vx < 0 &&
      newBx - BALL_R <= pLeft.x + PADDLE_W &&
      newBx + BALL_R >= pLeft.x &&
      newBy + BALL_R >= pLeft.y &&
      newBy - BALL_R <= pLeft.y + PADDLE_H) {
    ball.x = toFixed(pLeft.x + PADDLE_W + BALL_R + 1); newBx = toPixel(ball.x);
    ball.vx = (-ball.vx * BALL_ACCEL) / 100;
    // Ângulo baseado no ponto de impacto
    int impact = newBy - (pLeft.y + PADDLE_H/2);
    ball.vy += (long)impact * 7;
    drawPaddle(pLeft);
    pongCpuMove();
    ballDrawAndEraseTail(newBx, newBy, prevBallX, prevBallY);
    prevBallX = newBx; prevBallY = newBy;
    return;
  }

  // Colisão raquete direita (CPU)
  if (ball.vx > 0 &&
      newBx + BALL_R >= pRight.x &&
      newBx - BALL_R <= pRight.x + PADDLE_W &&
      newBy + BALL_R >= pRight.y &&
      newBy - BALL_R <= pRight.y + PADDLE_H) {
    ball.x = toFixed(pRight.x - BALL_R - 1); newBx = toPixel(ball.x);
    ball.vx = (-ball.vx * BALL_ACCEL) / 100;
    int impact = newBy - (pRight.y + PADDLE_H/2);
    ball.vy += (long)impact * 7;
    drawPaddle(pRight);
    pongCpuMove();
    ballDrawAndEraseTail(newBx, newBy, prevBallX, prevBallY);
    prevBallX = newBx; prevBallY = newBy;
    return;
  }

  // Ponto do CPU (bola saiu pela esquerda)
  if (newBx - BALL_R < 2) {
    prevBallX = -99; prevBallY = -99;
    pRight.score++;
    pongPointFlash(2); pongDrawHUD();
    if (pRight.score >= WIN_SCORE) {
      showVictory(2); victoryPending=true; victoryWinner=2; victoryStartTime=millis(); return;
    }
    pongResetPending=true; pongResetTimer=millis(); pongResetBall(-1);
    pongDrawArena(); drawPaddle(pLeft); drawPaddle(pRight);
    int bx2=toPixel(ball.x), by2=toPixel(ball.y);
    tft.fillCircle(bx2+2,by2+2,BALL_R,DARKGRAY);
    tft.fillCircle(bx2,  by2,  BALL_R,BALL_COL);
    tft.fillCircle(bx2-2,by2-2,BALL_R/2,WHITE);
    return;
  }

  // Ponto do jogador (bola saiu pela direita)
  if (newBx + BALL_R > SCREEN_W-2) {
    prevBallX = -99; prevBallY = -99;
    pLeft.score++;
    pongPointFlash(1); pongDrawHUD();
    if (pLeft.score >= WIN_SCORE) {
      showVictory(1); victoryPending=true; victoryWinner=1; victoryStartTime=millis();

      return;
    }
    pongResetPending=true; pongResetTimer=millis(); pongResetBall(1);
    pongDrawArena(); drawPaddle(pLeft); drawPaddle(pRight);
    int bx2=toPixel(ball.x), by2=toPixel(ball.y);
    tft.fillCircle(bx2+2,by2+2,BALL_R,DARKGRAY);
    tft.fillCircle(bx2,  by2,  BALL_R,BALL_COL);
    tft.fillCircle(bx2-2,by2-2,BALL_R/2,WHITE);
    return;
  }

  pongCpuMove();
  ballDrawAndEraseTail(newBx, newBy, prevBallX, prevBallY);
  prevBallX = newBx; prevBallY = newBy;
}

// ─────────────────────────────────────────────────────────────────────────────
// PONG LOOP — chamado a cada iteração do loop() principal
// ─────────────────────────────────────────────────────────────────────────────
void pongLoop(unsigned long now) {
  // Raquete: touch contínuo (segura o dedo) OU botões físicos BTN1=CIMA / BTN2=BAIXO
  if (touchIsPressed() && !isBackTouch(touchX(), touchY())) {
    pongMovePaddle(pLeft, touchY() - PADDLE_H/2);
  }
  // Botões físicos para mover a raquete do jogador
  #define PONG_BTN_STEP 6   // px por frame ao segurar o botão
  if (btnPressed(1)) { pongMovePaddle(pLeft, pLeft.y - PONG_BTN_STEP); }
  if (btnPressed(2)) { pongMovePaddle(pLeft, pLeft.y + PONG_BTN_STEP); }
  if (btnPressed(3)) { pongMovePaddle(pLeft, pLeft.y + PONG_BTN_STEP); }

  // BACK: exige borda de subida com debounce — usa justPressed
  if (touchJustPressed() && isBackTouch(touchX(), touchY())) {
    pongDone = true; return;
  }

  if (victoryPending) {
    if (now - victoryStartTime >= VICTORY_DELAY_MS) pongDone = true;
    return;
  }

  if (pongResetPending) {
    if (now - pongResetTimer >= POINT_DELAY_MS) pongResetPending = false;
    return;
  }

  if (now - lastPongUpdate >= PONG_INTERVAL) {
    lastPongUpdate = now;
    pongUpdate();
  }
}

bool pongIsDone()    { return pongDone; }
bool pongPlayerWon() { return pongDone && (victoryWinner == 1); }
