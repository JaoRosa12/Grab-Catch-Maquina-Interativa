#pragma once
/*
 * menu.h — Menu principal do Arcade
 */

#include <Arduino.h>
#include "graphics.h"

void drawMenu();
int  checkMenuTouch(int tx, int ty);  // retorna 1..4 ou 0
